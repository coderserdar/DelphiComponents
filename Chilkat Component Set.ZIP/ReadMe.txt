
This installation contains Chilkat Software's ActiveX component product line.
Some of the components are freeware, and others are shareware with 30-day
evaluation periods. 

The ChilkatDelphi.exe program installs the 9 components listed below:


1) Chilkat Mail, Freeware, includes Delphi example programs.


2) Chilkat Zip, 30-Day Trial, includes Delphi example programs.


3) Chilkat XML, Freeware, includes Delphi example programs.


4) Chilkat Crypt, 30-Day Trial, includes Delphi example programs.


5) Chilkat IConv, 30-Day Trial, includes Delphi example programs.


6) Chilkat XML Messaging, 30-Day Trial, example programs unavailable at time of submission.


7) Chilkat Certificate, Freeware, this component plays a supporting role for the others,
and is used in other component examples.


8) Chilkat Real-Time Compression, Freeware, no examples included.


9) Chilkat SSL, Freeware, no examples included.


All Chilkat components are documented exclusively and extensively on the Chilkat Software website: http://www.chilkatsoft.com


Best Regards,

Matt Fausey
President & CEO
Chilkat Software, Inc.
fausey@chilkatsoft.com
312-953-3949

