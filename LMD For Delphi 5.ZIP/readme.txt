LMD-Tools Special Edition
*************************
� 2001 by LMD Innovative (http://www.lmd.de)


Free Component Suite with more than 100 components for Delphi/CBuilder 5 
Date: 05/22/2001, Version 5.04


Welcome to LMD-Tools E-Edition! This package represents a free extract of more than 
100 components of our successful LMD-Tools component suite. Against the first release of 
the SE edition available on the Delphi 5 Companion CD this version is based on the current 
5.0 release of LMD-Tools and provides dozens of new features and enhancements. 
No restrictions exist - all components run outside the IDE as well. However against the 
full release only major components like the ButtonBar, SplitterPanel, Extended Dialog, 
Datasensitive or TLMDCalendar related controls are missing.

For complete feature list (especially the upcoming LMD-Tools 6 or LMD-Tools CLX release) 
check our web site at http://www.lmd.de.


Installation
============
Use SETUP.EXE to start the installation program and follow the instructions. The installer
tries to install package and help files automatically. A full featured installer and uninstalling 
instructions are provided. Please note that a compiled MegaDemo.EXE will be demonstrated as well
in the \bin folder of the installation directory. Check out this file for a demonstration of 
almost all components of the full LMD-Tools 5 release.

NOTE
====
If you used any previous or other release of LMD-Tools before: Please uninstall this version
COMPLETELY to avoid problems caused by mixing up two different versions.

If you encounter problems using this trial version feel free to contact us:

email: 			support@lmd.de
fax:			+49-271-356952
newsgroups:		news.lmdtools.com

Have fun with this trialversion.

LMD Innovative, Germany
