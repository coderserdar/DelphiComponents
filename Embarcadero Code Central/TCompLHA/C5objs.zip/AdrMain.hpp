// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdrMain.pas' rev: 5.00

#ifndef AdrMainHPP
#define AdrMainHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SegLHA.hpp>	// Pascal unit
#include <CompLHA.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <FileCtrl.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <Mask.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <DBTables.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Adrmain
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TMainForm;
class PASCALIMPLEMENTATION TMainForm : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Menus::TMainMenu* MainMenu;
	Menus::TMenuItem* MFile;
	Menus::TMenuItem* MBack;
	Menus::TMenuItem* MRest;
	Menus::TMenuItem* N1;
	Menus::TMenuItem* MExit;
	Stdctrls::TGroupBox* GroupBox1;
	Stdctrls::TLabel* Label1;
	Stdctrls::TLabel* Label2;
	Stdctrls::TLabel* Label3;
	Stdctrls::TLabel* Label4;
	Dbctrls::TDBEdit* EName;
	Dbctrls::TDBEdit* EAddress;
	Dbctrls::TDBEdit* ECity;
	Dbctrls::TDBEdit* EPhone;
	Menus::TMenuItem* MEdit;
	Menus::TMenuItem* MNew;
	Menus::TMenuItem* MChange;
	Menus::TMenuItem* MDelete;
	Menus::TMenuItem* MSearch;
	Menus::TMenuItem* MFind;
	Menus::TMenuItem* MFirst;
	Menus::TMenuItem* MNext;
	Menus::TMenuItem* MPrev;
	Menus::TMenuItem* MLast;
	Buttons::TSpeedButton* NextBtn;
	Buttons::TSpeedButton* PrevBtn;
	Stdctrls::TLabel* Label5;
	Dbctrls::TDBEdit* EEMail;
	Buttons::TBitBtn* CanBtn;
	Buttons::TBitBtn* SaveBtn;
	Db::TDataSource* DataSource;
	Dbtables::TTable* AdrTable;
	Db::TStringField* AdrTableName;
	Db::TStringField* AdrTableAddress;
	Db::TStringField* AdrTableCity;
	Db::TStringField* AdrTablePhone;
	Db::TStringField* AdrTableEMail;
	Menus::TMenuItem* MData;
	Menus::TMenuItem* MPurge;
	Extctrls::TPanel* MsgPanel;
	Dbtables::TQuery* TheQuery;
	Seglha::TSegLHA* SegLHA;
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormDestroy(System::TObject* Sender);
	void __fastcall PrevBtnClick(System::TObject* Sender);
	void __fastcall NextBtnClick(System::TObject* Sender);
	void __fastcall MExitClick(System::TObject* Sender);
	void __fastcall MNewClick(System::TObject* Sender);
	void __fastcall MChangeClick(System::TObject* Sender);
	void __fastcall MDeleteClick(System::TObject* Sender);
	void __fastcall CanBtnClick(System::TObject* Sender);
	void __fastcall SaveBtnClick(System::TObject* Sender);
	HIDESBASE void __fastcall DoKeyPress(System::TObject* Sender, char &Key);
	void __fastcall MPurgeClick(System::TObject* Sender);
	void __fastcall MFirstClick(System::TObject* Sender);
	void __fastcall MNextClick(System::TObject* Sender);
	void __fastcall MPrevClick(System::TObject* Sender);
	void __fastcall MLastClick(System::TObject* Sender);
	void __fastcall MFindClick(System::TObject* Sender);
	void __fastcall MBackClick(System::TObject* Sender);
	void __fastcall MRestClick(System::TObject* Sender);
	void __fastcall SegLHACheckFile(const AnsiString originalFilePath, AnsiString &newFilePath, int dateTime
		, Complha::TCompLHAProcessMode mode);
	
private:
	void __fastcall SetReadOnly(bool State);
	void __fastcall InitOptions(int RC);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TMainForm(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TMainForm(Classes::TComponent* AOwner, int Dummy
		) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TMainForm(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TMainForm(HWND ParentWindow) : Forms::TForm(ParentWindow
		) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TMainForm* MainForm;

}	/* namespace Adrmain */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Adrmain;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdrMain
