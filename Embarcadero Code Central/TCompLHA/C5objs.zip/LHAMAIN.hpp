// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'LHAmain.pas' rev: 5.00

#ifndef LHAmainHPP
#define LHAmainHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Mask.hpp>	// Pascal unit
#include <FileCtrl.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <CompLHA.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Lhamain
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TForm1;
class PASCALIMPLEMENTATION TForm1 : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Stdctrls::TGroupBox* ArchiveGroup;
	Stdctrls::TListBox* ListBox1;
	Stdctrls::TMemo* Memo4;
	Extctrls::TPanel* Status;
	Stdctrls::TGroupBox* GroupBox2;
	Filectrl::TDirectoryListBox* DL;
	Filectrl::TFileListBox* FL;
	Extctrls::TPanel* Panel3;
	Filectrl::TDriveComboBox* DCB;
	Stdctrls::TMemo* Memo3;
	Extctrls::TPanel* Panel2;
	Stdctrls::TLabel* ArchiveLabel;
	Stdctrls::TEdit* archivefile;
	Stdctrls::TLabel* Label2;
	Complha::TCompLHA* CompLHA1;
	Extctrls::TPanel* Panel1;
	Extctrls::TPanel* Panel4;
	Extctrls::TBevel* Bevel1;
	Stdctrls::TLabel* Time;
	Stdctrls::TLabel* Percentage;
	Stdctrls::TLabel* TimeLabel;
	Stdctrls::TLabel* Label7;
	Extctrls::TImage* Trashcan;
	Extctrls::TRadioGroup* CMethod;
	Stdctrls::TCheckBox* SaveFullPath;
	Stdctrls::TCheckBox* ConfirmOperations;
	Extctrls::TRadioGroup* ArchiveHeader;
	Stdctrls::TCheckBox* AllowDuplicates;
	Stdctrls::TCheckBox* VerifyExpands;
	Stdctrls::TButton* HelpButton;
	Stdctrls::TButton* AboutButton;
	Stdctrls::TButton* RegistrationButton;
	Stdctrls::TComboBox* Mask;
	Buttons::TSpeedButton* AbortButton;
	Stdctrls::TEdit* Edit1;
	Extctrls::TImage* Key;
	void __fastcall ResetFileInfo(void);
	void __fastcall SetDir(const AnsiString path);
	AnsiString __fastcall GetDir();
	void __fastcall CompressFiles(void);
	Complha::TCompLHAMethod __fastcall getCompressionMethod(void);
	void __fastcall showInfo(Complha::TCompLHA* tc);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall showfiles(void);
	void __fastcall ExpandDelete(Complha::TCompLHAProcessMode Operation, bool All);
	void __fastcall archivefileChange(System::TObject* Sender);
	void __fastcall DLDragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, Controls::TDragState 
		State, bool &Accept);
	void __fastcall archivefileDragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, 
		Controls::TDragState State, bool &Accept);
	void __fastcall archivefileDragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y)
		;
	void __fastcall DLDragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y);
	void __fastcall TrashcanDragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y);
	void __fastcall ListBox1Click(System::TObject* Sender);
	void __fastcall FLClick(System::TObject* Sender);
	void __fastcall CompLHA1CheckFile(const AnsiString originalFilePath, AnsiString &newFilePath, int DateTime
		, Complha::TCompLHAProcessMode mode);
	void __fastcall TrashcanDragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, Controls::TDragState 
		State, bool &Accept);
	void __fastcall FormActivate(System::TObject* Sender);
	void __fastcall CompLHA1ShowProgress(int &PercentageDone);
	void __fastcall Panel2Resize(System::TObject* Sender);
	void __fastcall SaveFullPathClick(System::TObject* Sender);
	void __fastcall CMethodClick(System::TObject* Sender);
	void __fastcall ConfirmOperationsClick(System::TObject* Sender);
	void __fastcall ArchiveHeaderClick(System::TObject* Sender);
	void __fastcall CMethodEnter(System::TObject* Sender);
	void __fastcall AllowDuplicatesClick(System::TObject* Sender);
	void __fastcall CompLHA1AfterProcessed(const AnsiString originalFilePath, const AnsiString newFilePath
		, int dateTime, Complha::TCompLHAProcessMode mode);
	void __fastcall AboutButtonClick(System::TObject* Sender);
	void __fastcall HelpButtonClick(System::TObject* Sender);
	void __fastcall RegistrationButtonClick(System::TObject* Sender);
	void __fastcall disableDragMode(void);
	void __fastcall enableDragMode(void);
	void __fastcall ExpandButtonClick(System::TObject* Sender);
	void __fastcall MaskChange(System::TObject* Sender);
	void __fastcall FillFileList(void);
	void __fastcall AbortButtonClick(System::TObject* Sender);
	void __fastcall Edit1Change(System::TObject* Sender);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TForm1(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TForm1(Classes::TComponent* AOwner, int Dummy
		) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TForm1(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TForm1(HWND ParentWindow) : Forms::TForm(ParentWindow
		) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TForm1* Form1;

}	/* namespace Lhamain */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Lhamain;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// LHAmain
