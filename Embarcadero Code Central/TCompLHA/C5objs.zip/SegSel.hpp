// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'SegSel.pas' rev: 5.00

#ifndef SegSelHPP
#define SegSelHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Segsel
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TSelForm;
class PASCALIMPLEMENTATION TSelForm : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* Panel1;
	Buttons::TBitBtn* ApplyBtn;
	Extctrls::TPanel* Panel2;
	Extctrls::TPanel* Panel3;
	Stdctrls::TGroupBox* GroupBox1;
	Stdctrls::TEdit* ETarget;
	Stdctrls::TListBox* LB;
	Stdctrls::TLabel* FileCnt;
	Buttons::TBitBtn* CanBtn;
	void __fastcall FormResize(System::TObject* Sender);
	void __fastcall LBKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	void __fastcall ApplyBtnClick(System::TObject* Sender);
	void __fastcall ETargetExit(System::TObject* Sender);
	void __fastcall CanBtnClick(System::TObject* Sender);
	
private:
	void __fastcall UpdateCount(void);
	
public:
	void __fastcall EntryPoint(AnsiString &Target, Classes::TStringList* &SL);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TSelForm(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TSelForm(Classes::TComponent* AOwner, int Dummy
		) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TSelForm(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TSelForm(HWND ParentWindow) : Forms::TForm(ParentWindow
		) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TSelForm* SelForm;

}	/* namespace Segsel */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Segsel;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SegSel
