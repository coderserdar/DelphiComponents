// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'SegLHA.pas' rev: 5.00

#ifndef SegLHAHPP
#define SegLHAHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <complha.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Seglha
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS ESegLHAError;
class PASCALIMPLEMENTATION ESegLHAError : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ESegLHAError(const AnsiString Msg) : Sysutils::Exception(Msg
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ESegLHAError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ESegLHAError(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ESegLHAError(int Ident, const System::TVarRec * Args
		, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ESegLHAError(const AnsiString Msg, int AHelpContext) : 
		Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ESegLHAError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ESegLHAError(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ESegLHAError(System::PResStringRec ResStringRec, 
		const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ESegLHAError(void) { }
	#pragma option pop
	
};


struct TSegIDHeader
{
	char HdrID[4];
	Word SegNumber;
} ;

struct TSegSetHeader
{
	char HdrID[4];
	Complha::TCompLHAMethod CompMode;
	System::TDateTime SegDate;
	int SegSize;
} ;

struct TSegScanHeader
{
	char HdrID[4];
	int ScanLen;
} ;

struct TSegArcHeader
{
	char HdrID[4];
	int ArcLen;
} ;

struct TFileInfo
{
	Complha::TCompLHAMethod CompressedMode;
	int CompressedSize;
	int FullSize;
	int Datetime;
	short Attributes;
	Byte HeaderLevel;
	Word CRC;
	int Position;
} ;

#pragma option push -b-
enum TSegMessageType { smTitle, smWrongSegMounted, smPrompt, smFreeSpaceMsg, smSegAbortMsg, smSegOpenMsg, 
	smScanOpenMsg, smArcOpenMsg, smSegNotFoundMsg, smCorrectCancelMsg, smSegIDHeaderMsg, smSegSetHeaderMsg, 
	smSegScanHeaderMsg, smSegArcHeaderMsg };
#pragma option pop

typedef void __fastcall (__closure *TSegChangeEvent)(const AnsiString SegPath);

typedef void __fastcall (__closure *TSegExpandEvent)(const AnsiString CurTargetPath, AnsiString &NewTargetPath
	, Classes::TStrings* &ListOfFiles);

typedef void __fastcall (__closure *TSegPromptEvent)(AnsiString &SegDir, const AnsiString SegName, Word 
	SegNumber);

class DELPHICLASS TSegLHA;
class PASCALIMPLEMENTATION TSegLHA : public Complha::TCompLHA 
{
	typedef Complha::TCompLHA inherited;
	
private:
	AnsiString FSegBaseName;
	AnsiString FSegDir;
	AnsiString FSegExt;
	Classes::TStrings* FSegMessages;
	int FSegSize;
	AnsiString FSegName;
	Word FSegNumber;
	AnsiString FSegPath;
	AnsiString FTmpFile;
	AnsiString FScanFile;
	AnsiString FArcFile;
	int FSegBytes;
	int FFreeBytes;
	int FTotalBytes;
	int FBytesProcessed;
	int FSegShowProgress;
	char *FBPtr;
	Classes::TComponent* FMyOwner;
	TSegChangeEvent FOnSegChange;
	TSegExpandEvent FOnSegExpand;
	TSegPromptEvent FOnSegPrompt;
	Complha::TCompLHAFilenameCheckEvent FSaveOnCheckFile;
	Complha::TCompLHAAfterProcessedEvent FSaveOnAfterProcessed;
	Complha::TCompLHAShowProgressEvent FSaveOnShowProgress;
	void __fastcall SetSegBaseName(const AnsiString SegBaseName);
	void __fastcall SetSegDir(const AnsiString SegDir);
	void __fastcall SetSegExt(const AnsiString SegExt);
	void __fastcall SetSegMessages(Classes::TStrings* Messages);
	void __fastcall SetSegSize(int SegSize);
	AnsiString __fastcall MakeTmpFile(const AnsiString Ext);
	void __fastcall OnCheckFileStub(const AnsiString originalFilePath, AnsiString &newFilePath, int dateTime
		, Complha::TCompLHAProcessMode mode);
	void __fastcall OnAfterProcessedStub(const AnsiString originalFilePath, const AnsiString newFilePath
		, int dateTime, Complha::TCompLHAProcessMode mode);
	void __fastcall OnShowProgressStub(int &PercentageDone);
	void __fastcall DisableEventHandlers(void);
	void __fastcall EnableEventHandlers(void);
	AnsiString __fastcall GetSegMessage(TSegMessageType MsgCnt);
	int __fastcall GetFileSize(const AnsiString FName);
	void __fastcall SetSegmentPath(void);
	AnsiString __fastcall AppendSlash(const AnsiString Path);
	void __fastcall RemoveFile(AnsiString &Path);
	void __fastcall RemoveSegFiles(void);
	float __fastcall CheckSpace(const AnsiString Path);
	bool __fastcall PathPrompt(AnsiString &DefDir, const int SegNum, const AnsiString SegName);
	void __fastcall NewSegmentEvent(void);
	void __fastcall SegmentArchive(void);
	void __fastcall AssembleArchive(bool VerifyOnly);
	void __fastcall ScanSegment(void);
	void __fastcall ReadSegSetHeader(Classes::TFileStream* &fh, TSegSetHeader &SetHdr);
	void __fastcall CreateScanFile(void);
	void __fastcall ReadScanFile(Classes::TFileStream* &fh);
	void __fastcall WriteScanFile(Classes::TFileStream* &fh);
	void __fastcall ReadArchiveFile(Classes::TFileStream* &fh);
	void __fastcall WriteArchiveFile(Classes::TFileStream* &fh);
	Classes::TFileStream* __fastcall CreateSegment(void);
	Classes::TFileStream* __fastcall OpenSegment(void);
	void __fastcall CloseSegment(Classes::TFileStream* &fh);
	void __fastcall WriteToSegment(Classes::TFileStream* &fh, void *Buffer, int Count);
	void __fastcall ReadFromSegment(Classes::TFileStream* &fh, void *Buffer, int Count);
	
public:
	__fastcall virtual TSegLHA(Classes::TComponent* AOwner);
	__fastcall virtual ~TSegLHA(void);
	virtual bool __fastcall Scan(void);
	virtual void __fastcall Compress(void);
	virtual void __fastcall Expand(void);
	virtual void __fastcall Verify(void);
	__property AnsiString SegName = {read=FSegName};
	__property Word SegNumber = {read=FSegNumber, nodefault};
	__property AnsiString SegPath = {read=FSegPath};
	
__published:
	__property AnsiString SegBaseName = {read=FSegBaseName, write=SetSegBaseName};
	__property AnsiString SegDir = {read=FSegDir, write=SetSegDir};
	__property AnsiString SegExt = {read=FSegExt, write=SetSegExt};
	__property Classes::TStrings* SegMessages = {read=FSegMessages, write=SetSegMessages};
	__property int SegSize = {read=FSegSize, write=SetSegSize, nodefault};
	__property TSegChangeEvent OnSegChange = {read=FOnSegChange, write=FOnSegChange};
	__property TSegExpandEvent OnSegExpand = {read=FOnSegExpand, write=FOnSegExpand};
	__property TSegPromptEvent OnSegPrompt = {read=FOnSegPrompt, write=FOnSegPrompt};
};


typedef AnsiString SegLHA__3[14];

//-- var, const, procedure ---------------------------------------------------
static const Word MINFREE = 0x800;
static const Word BUFSIZE = 0x2000;
#define SSID "SSID"
#define SSET "SSET"
#define SSCN "SSCN"
#define SARC "SARC"
#define CR "\n\r"
static const char NUL = '\x0';
extern PACKAGE AnsiString SegMessageDefaults[14];
extern PACKAGE void __fastcall Register(void);

}	/* namespace Seglha */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Seglha;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SegLHA
