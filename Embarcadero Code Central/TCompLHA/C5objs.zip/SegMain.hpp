// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'SegMain.pas' rev: 5.00

#ifndef SegMainHPP
#define SegMainHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <SegLHA.hpp>	// Pascal unit
#include <CompLHA.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <FileCtrl.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Segmain
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TSegForm;
class PASCALIMPLEMENTATION TSegForm : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Menus::TMainMenu* MenuBar;
	Menus::TMenuItem* MFile;
	Menus::TMenuItem* MExit;
	Extctrls::TPanel* Panel1;
	Extctrls::TPanel* Panel2;
	Menus::TMenuItem* MConfigure;
	Menus::TMenuItem* N1;
	Stdctrls::TLabel* Label1;
	Stdctrls::TEdit* ETemplate;
	Filectrl::TDriveComboBox* DCB;
	Filectrl::TDirectoryListBox* DLB;
	Filectrl::TFileListBox* FLB;
	Extctrls::TPanel* Panel3;
	Stdctrls::TGroupBox* GLB;
	Stdctrls::TListBox* LB;
	Buttons::TBitBtn* CompressBtn;
	Buttons::TBitBtn* ExpandBtn;
	Buttons::TBitBtn* ScanBtn;
	Buttons::TBitBtn* VerifyBtn;
	Menus::TMenuItem* MCommands;
	Menus::TMenuItem* MCompress;
	Menus::TMenuItem* MExpand;
	Menus::TMenuItem* MScan;
	Menus::TMenuItem* MVerify;
	Menus::TMenuItem* N2;
	Menus::TMenuItem* MReset;
	Buttons::TBitBtn* ConfigBtn;
	Buttons::TBitBtn* ResetBtn;
	Extctrls::TPanel* Banner;
	Stdctrls::TLabel* Label2;
	Stdctrls::TLabel* Label3;
	Stdctrls::TGroupBox* MsgBox;
	Stdctrls::TListBox* MsgLB;
	Extctrls::TPanel* ShowProg;
	Stdctrls::TLabel* FileCnt;
	Stdctrls::TLabel* Percent;
	Menus::TMenuItem* MFlush;
	Seglha::TSegLHA* SegLHA;
	void __fastcall LBDragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y);
	void __fastcall LBDragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, Controls::TDragState 
		State, bool &Accept);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall FormResize(System::TObject* Sender);
	void __fastcall ETemplateChange(System::TObject* Sender);
	void __fastcall ResetBtnClick(System::TObject* Sender);
	void __fastcall ConfigBtnClick(System::TObject* Sender);
	void __fastcall FLBDblClick(System::TObject* Sender);
	void __fastcall CompressBtnClick(System::TObject* Sender);
	void __fastcall LBKeyDown(System::TObject* Sender, Word &Key, Classes::TShiftState Shift);
	void __fastcall ScanBtnClick(System::TObject* Sender);
	void __fastcall ExpandBtnClick(System::TObject* Sender);
	void __fastcall VerifyBtnClick(System::TObject* Sender);
	void __fastcall MExitClick(System::TObject* Sender);
	void __fastcall MFlushClick(System::TObject* Sender);
	void __fastcall SegLHASegChange(AnsiString SegPath);
	void __fastcall SegLHAShowProgress(int &PercentageDone);
	void __fastcall SegLHASegExpand(AnsiString CurTargetPath, AnsiString &NewTargetPath, Classes::TStrings* 
		&ListOfFiles);
	void __fastcall SegLHACheckFile(const AnsiString originalFilePath, AnsiString &newFilePath, int dateTime
		, Complha::TCompLHAProcessMode mode);
	
private:
	void __fastcall InitButtons(bool cnf, bool cmp, bool exp, bool scn, bool ver);
	void __fastcall InitFileSelect(bool State);
	void __fastcall AddToLB(AnsiString path, bool UniqueFlag);
	void __fastcall AddToMsgLB(AnsiString Msg);
	void __fastcall BuildFileList(AnsiString DirPath, AnsiString Template);
	void __fastcall UpdateCount(void);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TSegForm(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TSegForm(Classes::TComponent* AOwner, int Dummy
		) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TSegForm(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TSegForm(HWND ParentWindow) : Forms::TForm(ParentWindow
		) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TSegForm* SegForm;

}	/* namespace Segmain */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Segmain;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SegMain
