// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'complha.pas' rev: 5.00

#ifndef complhaHPP
#define complhaHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Consts.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Complha
{
//-- type declarations -------------------------------------------------------
typedef char textbuffer[4156];

typedef char *textbufptr;

typedef short lsons[4097];

typedef short *lsonptr;

typedef short rsons[8194];

typedef short *rsonptr;

typedef short dads[4098];

typedef short *dadptr;

typedef char samebuf[4098];

typedef char *samebufptr;

typedef Word freqs[628];

typedef Word *freqptr;

typedef short prnts[942];

typedef short *prntptr;

typedef short sons[628];

typedef short *sonptr;

typedef char textbuffer5[16641];

typedef char levelbuffer[8449];

typedef char childcountbuffer[8449];

typedef short node;

typedef short positionbuffer[8449];

typedef short *positionptr;

typedef short parentbuffer[16385];

typedef short prevbuffer[16385];

typedef short nextbuffer[28913];

typedef char buffer[16385];

typedef char *bufferptr;

typedef Word childBuffer[1020];

typedef Word chartablebuffer[4097];

typedef Word charcodebuffer[511];

typedef Word positiontablebuffer[257];

typedef char charlenbuffer[511];

typedef Word positioncodebuffer[129];

class DELPHICLASS ELZHBadDecodeTable;
class PASCALIMPLEMENTATION ELZHBadDecodeTable : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ELZHBadDecodeTable(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ELZHBadDecodeTable(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ELZHBadDecodeTable(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ELZHBadDecodeTable(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ELZHBadDecodeTable(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ELZHBadDecodeTable(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ELZHBadDecodeTable(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ELZHBadDecodeTable(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ELZHBadDecodeTable(void) { }
	#pragma option pop
	
};


class DELPHICLASS EUnableToCompress;
class PASCALIMPLEMENTATION EUnableToCompress : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EUnableToCompress(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EUnableToCompress(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EUnableToCompress(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EUnableToCompress(int Ident, const System::TVarRec * 
		Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EUnableToCompress(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EUnableToCompress(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EUnableToCompress(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EUnableToCompress(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EUnableToCompress(void) { }
	#pragma option pop
	
};


class DELPHICLASS ECompLHAInsufficientDiskSpace;
class PASCALIMPLEMENTATION ECompLHAInsufficientDiskSpace : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ECompLHAInsufficientDiskSpace(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ECompLHAInsufficientDiskSpace(const AnsiString Msg, const 
		System::TVarRec * Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ECompLHAInsufficientDiskSpace(int Ident)/* overload */ : 
		Sysutils::Exception(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ECompLHAInsufficientDiskSpace(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ECompLHAInsufficientDiskSpace(const AnsiString Msg, int 
		AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ECompLHAInsufficientDiskSpace(const AnsiString Msg, 
		const System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args
		, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ECompLHAInsufficientDiskSpace(int Ident, int AHelpContext
		)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ECompLHAInsufficientDiskSpace(System::PResStringRec 
		ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : 
		Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ECompLHAInsufficientDiskSpace(void) { }
	#pragma option pop
	
};


class DELPHICLASS ECompLHACouldNotRenameFile;
class PASCALIMPLEMENTATION ECompLHACouldNotRenameFile : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ECompLHACouldNotRenameFile(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ECompLHACouldNotRenameFile(const AnsiString Msg, const 
		System::TVarRec * Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ECompLHACouldNotRenameFile(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ECompLHACouldNotRenameFile(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ECompLHACouldNotRenameFile(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ECompLHACouldNotRenameFile(const AnsiString Msg, const 
		System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size
		, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ECompLHACouldNotRenameFile(int Ident, int AHelpContext
		)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ECompLHACouldNotRenameFile(System::PResStringRec 
		ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : 
		Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ECompLHACouldNotRenameFile(void) { }
	#pragma option pop
	
};


class DELPHICLASS ECompLHAUnrecognizedCompressionMethod;
class PASCALIMPLEMENTATION ECompLHAUnrecognizedCompressionMethod : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ECompLHAUnrecognizedCompressionMethod(const AnsiString Msg
		) : Sysutils::Exception(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ECompLHAUnrecognizedCompressionMethod(const AnsiString 
		Msg, const System::TVarRec * Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ECompLHAUnrecognizedCompressionMethod(int Ident)/* overload */
		 : Sysutils::Exception(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ECompLHAUnrecognizedCompressionMethod(int Ident, const 
		System::TVarRec * Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ECompLHAUnrecognizedCompressionMethod(const AnsiString 
		Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ECompLHAUnrecognizedCompressionMethod(const AnsiString 
		Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg
		, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ECompLHAUnrecognizedCompressionMethod(int Ident, int 
		AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ECompLHAUnrecognizedCompressionMethod(System::PResStringRec 
		ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : 
		Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ECompLHAUnrecognizedCompressionMethod(void) { }
	#pragma option pop
	
};


class DELPHICLASS ECompLHAInvalidHeaderLevel;
class PASCALIMPLEMENTATION ECompLHAInvalidHeaderLevel : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ECompLHAInvalidHeaderLevel(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ECompLHAInvalidHeaderLevel(const AnsiString Msg, const 
		System::TVarRec * Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ECompLHAInvalidHeaderLevel(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ECompLHAInvalidHeaderLevel(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ECompLHAInvalidHeaderLevel(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ECompLHAInvalidHeaderLevel(const AnsiString Msg, const 
		System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size
		, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ECompLHAInvalidHeaderLevel(int Ident, int AHelpContext
		)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ECompLHAInvalidHeaderLevel(System::PResStringRec 
		ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : 
		Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ECompLHAInvalidHeaderLevel(void) { }
	#pragma option pop
	
};


class DELPHICLASS ECompLHAInvalidHeader;
class PASCALIMPLEMENTATION ECompLHAInvalidHeader : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ECompLHAInvalidHeader(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ECompLHAInvalidHeader(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ECompLHAInvalidHeader(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ECompLHAInvalidHeader(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ECompLHAInvalidHeader(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ECompLHAInvalidHeader(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ECompLHAInvalidHeader(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ECompLHAInvalidHeader(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ECompLHAInvalidHeader(void) { }
	#pragma option pop
	
};


class DELPHICLASS ECompLHABadChecksum;
class PASCALIMPLEMENTATION ECompLHABadChecksum : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ECompLHABadChecksum(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ECompLHABadChecksum(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ECompLHABadChecksum(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ECompLHABadChecksum(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ECompLHABadChecksum(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ECompLHABadChecksum(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ECompLHABadChecksum(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ECompLHABadChecksum(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ECompLHABadChecksum(void) { }
	#pragma option pop
	
};


class DELPHICLASS ECompLHABadCRC;
class PASCALIMPLEMENTATION ECompLHABadCRC : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ECompLHABadCRC(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ECompLHABadCRC(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ECompLHABadCRC(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ECompLHABadCRC(int Ident, const System::TVarRec * Args
		, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ECompLHABadCRC(const AnsiString Msg, int AHelpContext)
		 : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ECompLHABadCRC(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ECompLHABadCRC(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ECompLHABadCRC(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ECompLHABadCRC(void) { }
	#pragma option pop
	
};


class DELPHICLASS ECompLHAOperationAborted;
class PASCALIMPLEMENTATION ECompLHAOperationAborted : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ECompLHAOperationAborted(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ECompLHAOperationAborted(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ECompLHAOperationAborted(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ECompLHAOperationAborted(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ECompLHAOperationAborted(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ECompLHAOperationAborted(const AnsiString Msg, const 
		System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size
		, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ECompLHAOperationAborted(int Ident, int AHelpContext
		)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ECompLHAOperationAborted(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ECompLHAOperationAborted(void) { }
	#pragma option pop
	
};


class DELPHICLASS EcompLHAEncrypted;
class PASCALIMPLEMENTATION EcompLHAEncrypted : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EcompLHAEncrypted(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EcompLHAEncrypted(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EcompLHAEncrypted(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EcompLHAEncrypted(int Ident, const System::TVarRec * 
		Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EcompLHAEncrypted(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EcompLHAEncrypted(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EcompLHAEncrypted(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EcompLHAEncrypted(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EcompLHAEncrypted(void) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TCompLHAArchiveType { caLHARC, caLHA };
#pragma option pop

#pragma option push -b-
enum TCompLHAMethod { colh0, colh1, colh5, coTCR };
#pragma option pop

#pragma option push -b-
enum TCompLHAProcessMode { cmLHACompress, cmLHAExpand, cmLHADelete };
#pragma option pop

struct TCompLHAFileHeader
{
	Byte HeaderSize;
	Byte HeaderChecksum;
	char ComMethodId[5];
	int CompressedSize;
	int FullSize;
	Word FileTime;
	Word FileDate;
	Byte Attributes;
	Byte HeaderLevel;
	Byte FileNameLength;
} ;

class DELPHICLASS TCompLHAFileInfo;
class PASCALIMPLEMENTATION TCompLHAFileInfo : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	TCompLHAMethod CompressedMode;
	int CompressedSize;
	int Fullsize;
	int Datetime;
	short Attributes;
	Byte HeaderLevel;
	Word CRC;
	int Position;
	bool Encrypted;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TCompLHAFileInfo(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TCompLHAFileInfo(void) { }
	#pragma option pop
	
};


typedef void __fastcall (__closure *TCompLHAFilenameCheckEvent)(const AnsiString originalFilePath, AnsiString 
	&newFilePath, int dateTime, TCompLHAProcessMode mode);

typedef void __fastcall (__closure *TCompLHAAfterProcessedEvent)(const AnsiString originalFilePath, 
	const AnsiString newFilePath, int dateTime, TCompLHAProcessMode mode);

typedef void __fastcall (__closure *TCompLHAShowProgressEvent)(int &PercentageDone);

class DELPHICLASS TLHAFileStream;
class PASCALIMPLEMENTATION TLHAFileStream : public Classes::TFileStream 
{
	typedef Classes::TFileStream inherited;
	
public:
	__fastcall TLHAFileStream(const AnsiString FileName, Word Mode);
public:
	#pragma option push -w-inl
	/* TFileStream.Destroy */ inline __fastcall virtual ~TLHAFileStream(void) { }
	#pragma option pop
	
};


class DELPHICLASS TCrackHandleStream;
class PASCALIMPLEMENTATION TCrackHandleStream : public Classes::TStream 
{
	typedef Classes::TStream inherited;
	
private:
	int FHandle;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TCrackHandleStream(void) : Classes::TStream() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TCrackHandleStream(void) { }
	#pragma option pop
	
};


class DELPHICLASS TCompLHAThreadSafety;
class PASCALIMPLEMENTATION TCompLHAThreadSafety : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	bool AtStart;
	bool InputEOF;
	bool inRepeat;
	char *inBuffer;
	char *outBuffer;
	char *inBmax;
	char *inBptr;
	char *outBmax;
	char *outBptr;
	Classes::TStream* source;
	Classes::TStream* dest;
	char lastch;
	int DupCount;
	int InChecksum;
	int Outchecksum;
	int Readsize;
	int lChunk;
	int BytesIn;
	int BytesOut;
	bool EncryptingIn;
	bool EncryptingOut;
	Byte EncryptCodes[4];
	short EncryptCounter;
	int MaxNumberOfBytesToWrite;
	TCompLHAShowProgressEvent GlobalFOnShowProgress;
	bool *GlobalAbortptr;
	Word InCRC;
	Word OutCRC;
	char *text_buf;
	short *lson;
	short *rson;
	short *dad;
	char *same;
	Word *freq;
	short *prnt;
	short *son;
	Word putbuf;
	char putlen;
	Word getbuf;
	char getlen;
	Word match_position;
	Word match_length;
	char *text;
	char *level;
	char *childcount;
	short *position;
	short *parent;
	short *prev;
	char *buf;
	char subBitbuf;
	char Bitcount;
	Word Blocksize;
	Word bitbuf;
	Word *left;
	Word *right;
	char *charLen;
	char position_len[129];
	Word *char_freq;
	Word *char_table;
	Word *char_code;
	Word position_freq[28];
	Word *position_table;
	Word *position_code;
	Word t_freq[38];
	short pos;
	short MatchPosition;
	short avail;
	short *next;
	char depth;
	Word output_pos;
	Word output_mask;
	Word cpos;
	short remainder;
	short MatchLength;
	char __fastcall GetChar(void);
	char __fastcall Encrypt(char ch);
	void __fastcall PutChar(char ch);
	void __fastcall CopyWithCRC(void);
	void __fastcall ExpandRLE(void);
	void __fastcall StartHuff(void);
	void __fastcall EndHuff(void);
	void __fastcall reconst(void);
	void __fastcall update(Word c);
	void __fastcall InitTree(void);
	void __fastcall InsertNode(short r);
	void __fastcall link(short n, short p, short q);
	void __fastcall linknode(short p, short q, short r);
	void __fastcall DeleteNode(short p);
	void __fastcall Putcode(short L, Word c);
	void __fastcall EncodeChar(Word c);
	void __fastcall EncodePosition(Word c);
	void __fastcall EncodeEnd(void);
	void __fastcall CompressLZH(void);
	short __fastcall GetBit(void);
	Word __fastcall GetByte(void);
	short __fastcall GetNBits(Word n);
	short __fastcall DecodeChar(void);
	short __fastcall DecodePosition(void);
	void __fastcall ExpandLZH(int textsize);
	void __fastcall StartHuff5(bool Compress);
	void __fastcall EndHuff5(void);
	void __fastcall buildtable(short nchar, const char * bitlen, const int bitlen_Size, short tablebits
		, Word * table, const int table_Size);
	void __fastcall fillbuf(char n);
	Word __fastcall getbits(char n);
	void __fastcall read_position_len(short nn, short nbit, short i_special);
	void __fastcall read_charLen(void);
	Word __fastcall DecodeChar5(void);
	Word __fastcall DecodePosition5(void);
	void __fastcall ExpandLZH5(int destsize);
	short __fastcall buildtree(short nparm, Word * freqparm, const int freqparm_Size, char * lenparm, const 
		int lenparm_Size, Word * codeparm, const int codeparm_Size);
	void __fastcall count_t_freq(void);
	void __fastcall initSlide(void);
	short __fastcall child(short q, char c);
	void __fastcall makechild(short q, char c, short r);
	void __fastcall split(short old);
	void __fastcall insert_node(void);
	void __fastcall delete_node(void);
	void __fastcall putcode5(char n, Word x);
	void __fastcall putbits(char n, Word x);
	void __fastcall write_position_len(short n, short nbit, short i_special);
	void __fastcall write_charLen(void);
	void __fastcall encode_char(short c);
	void __fastcall encode_position(Word p);
	void __fastcall send_block(void);
	void __fastcall OutputCodes(Word c, Word p);
	void __fastcall get_next_match(void);
	void __fastcall CompressLZH5(void);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TCompLHAThreadSafety(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TCompLHAThreadSafety(void) { }
	#pragma option pop
	
};


class DELPHICLASS TCompLHA;
class PASCALIMPLEMENTATION TCompLHA : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	TCompLHAThreadSafety* Global;
	AnsiString FRegName;
	int FRegNumber;
	int FCompressedToPercentage;
	unsigned FCompressionTime;
	TCompLHAFilenameCheckEvent FOnCheckFile;
	TCompLHAAfterProcessedEvent FOnAfterProcessed;
	TCompLHAShowProgressEvent FOnShowProgress;
	AnsiString FTargetPath;
	bool FMakeDirectories;
	bool FExceptionOnFileError;
	TCompLHAArchiveType FArchiveType;
	bool FStorePath;
	bool FAllowDuplicates;
	bool FSafeMode;
	bool FVerifyMode;
	bool FForceUpperCase;
	bool FConfirm;
	AnsiString FArchiveName;
	TCompLHAMethod FCompressionMethod;
	Classes::TStrings* FFileList;
	Classes::TList* FFileInformation;
	Classes::TStrings* FFilesToProcess;
	Classes::TStrings* FFilesProcessed;
	Classes::TStrings* FConfirmMessages;
	AnsiString FTempArchivePath;
	bool FAbortOperation;
	bool FCheckSpaceBeforeExpand;
	AnsiString FPassword;
	int FFileInformationIndex;
	bool FisTCompressArchive;
	bool __fastcall CheckForTCompressArchive(Classes::TStream* compressedFile);
	bool __fastcall GetTCompressFileHeader(Classes::TStream* Stream, TCompLHAFileHeader &Fhdr, AnsiString 
		&Filename, Word &crc);
	Classes::TFileStream* __fastcall CreateNewArchive(const AnsiString archivePath);
	Classes::TFileStream* __fastcall OpenArchiveForAppend(const AnsiString archivePath, int &truncatepos
		);
	int __fastcall CheckDiskSpace(AnsiString filename);
	void __fastcall ExpandOrVerify(bool verify);
	void __fastcall CheckConfirm(const AnsiString origFilename, AnsiString &newfilename, TCompLHAProcessMode 
		mode);
	void __fastcall SetFilesToProcess(Classes::TStrings* Files);
	void __fastcall SetConfirmMessages(Classes::TStrings* Messages);
	void __fastcall SetTempArchivePath(const AnsiString path);
	void __fastcall SetTargetPath(const AnsiString path);
	int __fastcall GetCompressedPercentage(void);
	AnsiString __fastcall FixStoredFilename(AnsiString s);
	int __fastcall ProcessStreams(Classes::TStream* outstream, Classes::TStream* instream, int Sourcesize
		, int destSize, TCompLHAMethod CompressionMethod, Word &crc, TCompLHAProcessMode mode, bool encrypted
		);
	
protected:
	void __fastcall AppendFilesExcept(const AnsiString destfile, const AnsiString fromfile, Classes::TStrings* 
		notfiles, bool recordProcessed);
	void __fastcall Truncatefile(const AnsiString filename, int truncatepos);
	bool __fastcall GetFileHeader(Classes::TStream* Stream, TCompLHAFileHeader &Fhdr, AnsiString &Filename
		, Word &crc);
	void __fastcall PutFileHeader(Classes::TStream* Stream, TCompLHAFileHeader &Fhdr, AnsiString Filename
		, Word crc);
	void __fastcall ScanCompressedStream(Classes::TStream* compressedstream, Classes::TStringList* &Finfo
		);
	int __fastcall DoCompress(Classes::TStream* compressedStream, Classes::TStream* uncompressedStream, 
		TCompLHAMethod compressionMethod, Word &crc);
	void __fastcall DoExpand(Classes::TStream* expandedStream, Classes::TStream* unexpandedStream, int 
		compressedsize, int fullsize, Word crc, TCompLHAMethod compressionMethod, bool encrypted);
	TCompLHAMethod __fastcall Recognize(const AnsiString cID);
	void __fastcall CompressStreamToArchiveStream(Classes::TStream* compressedStream, Classes::TStream* 
		uncompressedStream, const AnsiString Filename, const TCompLHAFileHeader &FHdr, TCompLHAMethod CompressionMode
		);
	void __fastcall ForceDirectories(AnsiString Dir);
	void __fastcall FreeFileInfo(void);
	
public:
	__fastcall virtual TCompLHA(Classes::TComponent* AOwner);
	__fastcall virtual ~TCompLHA(void);
	float __fastcall DiskFree(Byte Drive);
	virtual bool __fastcall Scan(void);
	virtual void __fastcall Compress(void);
	virtual void __fastcall Expand(void);
	virtual void __fastcall Verify(void);
	void __fastcall Delete(void);
	__property Classes::TStrings* FileList = {read=FFileList, write=FFileList};
	__property Classes::TStrings* FilesProcessed = {read=FFilesProcessed, write=FFilesProcessed};
	__property Classes::TList* FileInformation = {read=FFileInformation, write=FFileInformation};
	__property bool isTCompressArchive = {read=FisTCompressArchive, write=FisTCompressArchive, nodefault
		};
	void __fastcall CompressFiles(const AnsiString arcFile, Classes::TStrings* whichfiles, TCompLHAMethod 
		CompressionMode);
	void __fastcall CompressFile(const AnsiString arcfile, AnsiString &fromFile, TCompLHAMethod CompressionMode
		);
	void __fastcall DeleteFiles(const AnsiString arcFile, Classes::TStrings* whichfiles);
	void __fastcall ExpandFile(AnsiString &toFile, const AnsiString arcfile);
	void __fastcall ExpandFiles(const AnsiString arcfile, Classes::TStrings* whichfiles);
	void __fastcall ScanCompressedFile(const AnsiString arcfile, Classes::TStringList* &Finfo);
	__property int CompressedPercentage = {read=GetCompressedPercentage, nodefault};
	__property unsigned CompressionTime = {read=FCompressionTime, nodefault};
	void __fastcall FreeFileList(Classes::TStringList* Finfo);
	void __fastcall GetAllFilesInDir(Classes::TStrings* list, AnsiString dirname, const AnsiString match
		, bool Anything);
	void __fastcall GetMatchingFiles(Classes::TStrings* list, const AnsiString matchname);
	bool __fastcall FileInList(Classes::TStrings* whichFiles, const AnsiString filename);
	bool __fastcall MatchFileName(const AnsiString Filename, const AnsiString FilenameMask);
	__property bool AbortOperation = {read=FAbortOperation, write=FAbortOperation, nodefault};
	void __fastcall ExpandFilesFromStream(Classes::TStream* compressedstream, Classes::TStrings* whichfiles
		);
	void __fastcall CompressFilesToStream(Classes::TStream* dest, Classes::TStrings* &whichfiles, TCompLHAMethod 
		CompressionMode);
	void __fastcall CompressStreamToArchive(const AnsiString arcFile, Classes::TStream* uncompressedStream
		, AnsiString fileName, TCompLHAMethod CompressionMode);
	void __fastcall ExpandStreamFromArchive(const AnsiString arcFile, Classes::TStream* uncompressedStream
		, const AnsiString fileName);
	
__published:
	__property AnsiString RegName = {read=FRegName, write=FRegName};
	__property int RegNumber = {read=FRegNumber, write=FRegNumber, nodefault};
	__property TCompLHAFilenameCheckEvent OnCheckFile = {read=FOnCheckFile, write=FOnCheckFile};
	__property TCompLHAAfterProcessedEvent OnAfterProcessed = {read=FOnAfterProcessed, write=FOnAfterProcessed
		};
	__property TCompLHAShowProgressEvent OnShowProgress = {read=FOnShowProgress, write=FOnShowProgress}
		;
	__property AnsiString TargetPath = {read=FTargetPath, write=SetTargetPath};
	__property bool MakeDirectories = {read=FMakeDirectories, write=FMakeDirectories, nodefault};
	__property bool SafeMode = {read=FSafeMode, write=FSafeMode, nodefault};
	__property bool VerifyMode = {read=FVerifyMode, write=FVerifyMode, nodefault};
	__property TCompLHAArchiveType ArchiveType = {read=FArchiveType, write=FArchiveType, nodefault};
	__property bool AllowDuplicates = {read=FAllowDuplicates, write=FAllowDuplicates, nodefault};
	__property bool StorePath = {read=FStorePath, write=FStorePath, nodefault};
	__property bool ForceUpperCase = {read=FForceUpperCase, write=FForceUpperCase, nodefault};
	__property bool ExceptionOnFileError = {read=FExceptionOnFileError, write=FExceptionOnFileError, nodefault
		};
	__property AnsiString ArchiveName = {read=FArchiveName, write=FArchiveName};
	__property TCompLHAMethod CompressionMethod = {read=FCompressionMethod, write=FCompressionMethod, nodefault
		};
	__property Classes::TStrings* FilesToProcess = {read=FFilesToProcess, write=SetFilesToProcess};
	__property Classes::TStrings* ConfirmMessages = {read=FConfirmMessages, write=SetConfirmMessages};
	__property bool Confirm = {read=FConfirm, write=FConfirm, nodefault};
	__property AnsiString TempArchivePath = {read=FTempArchivePath, write=SetTempArchivePath};
	__property bool CheckSpaceBeforeExpand = {read=FCheckSpaceBeforeExpand, write=FCheckSpaceBeforeExpand
		, nodefault};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property int FileInformationIndex = {read=FFileInformationIndex, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
static const Word N = 0x1000;
static const Word TNIL = 0x1000;
static const Shortint F = 0x3c;
static const Shortint THRESHOLD = 0x2;
static const Word N_CHAR = 0x13a;
static const Word T = 0x273;
static const Word R = 0x272;
static const Word MAX_FREQ = 0x8000;
static const Word MaxMatch = 0x100;
static const Shortint DictionaryBits = 0xd;
static const Word DictionarySize = 0x2000;
static const Shortint Hash1 = 0x4;
static const Word Hash2 = 0x4000;
static const Byte CharMax = 0xff;
static const Word WordMax = 0xffff;
static const Shortint WordBits = 0x10;
static const Word SmallintMax = 0x7fff;
static const short SmallintMin = 0xffff8000;
static const Word max_hash_val = 0x70ef;
static const Word BufferSize = 0x4000;
static const Shortint Threshold5 = 0x3;
static const Word NC = 0x1fe;
static const Shortint CBIT = 0x9;
static const Shortint PBIT = 0x4;
static const Shortint TBIT = 0x5;
static const Shortint NP = 0xe;
static const Shortint NT = 0x13;
static const Byte NPT = 0x80;
static const Shortint NIL5 = 0x0;
#define SFCreateError "Cannot create file %s"
static const char CompLHANoMoreFlag = '\x2a';
#define CompLHASkipFlag ""
extern PACKAGE void __fastcall Register(void);

}	/* namespace Complha */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Complha;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// complha
