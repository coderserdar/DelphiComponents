
Make sure you extract the component files and dlls 
into the same directory as the demo before compiling.