
//------------------------------------------------------------
                    Zipdll.dll & Unzdll.dll
//------------------------------------------------------------

     Author:  Eric W. Engler
     
     http://www.geocities.com/SiliconValley/Network/2114/
     englere@abraxis.com

     Copyright � 1998 - 2001.

//------------------------------------------------------------
                      Distribution Policy
             Guidelines for Legal Re-distribution of
                    Zipdll.dll & Unzdll.dll
//------------------------------------------------------------

  1) This applies to both end-users and developers.  
    
  2) You must not charge money for the dlls.

  3) You MUST either distribute the source code for these 
     dlls, or give a WWW site where they can be obtained 
     freely. This can be on a Help...About screen, in printed
     documentation, or in text files distributed with your 
     package.  Yes, it does seem odd to have this requirement
     for end-users who aren't programmers, but there is no
     mistake.  After all, it isn't hard to give them a URL
     and a few words explaining what it is for.

  4) You must document the Info-Zip's WWW home page URL, but 
     don't expect any help from the Info-Zip group, since my 
     release is only a derrivitive of their work.  They are 
     very busy doing support for their "official" releases.
     Since much of the DLL source code comes from them, they
     deserve to be mentioned.
        Info-Zip:   http://www.cdrom.com/pub/infozip/

  5) You must handle product support with your own end-users.
     This is needed because I don't have enough time to do
     support for end-users.

  6) I will handle support issues with programmers using this 
     package on a time-available basis. Since this is being
     distributed as freeware, you can't expect the kind of 
     support you'd get from a commercial vendor.  Please limit
     your questions to those that directly pertain to this
     ZIP package.

//------------------------------------------------------------
                      LEGAL DISCLAIMER
//------------------------------------------------------------

     This freeware release is provided free and "as-is".
     Like anything else that's free, these dlls come with no 
     warranty of any kind, either expressed or implied. 
     In no event will the copyright holders be liable
     for any damages resulting from the proper or improper
     use of this software.

//------------------------------------------------------------
