{===============================================================}
     RichView Package 1.5 for Delphi 6 (Companion CD)
{===============================================================}
  Shareware version is fully functional, but displays red
  label when program is running.
{---------------------------------------------------------------}
                      RICHVIEW IS...
  RichView is a suite of native Delphi/C++Builder components
  for displaying, editing and printing hypertext documents.

  Components support various character attributes (fonts, 
  subscripts/superscripts, colored text background, custom drawn).

  Documents can contain tables, pictures, images from imagelists, 
  any Delphi controls.
  Left, right, center or justify alignments of paragraphs, 
  custom margins and indents, Unicode, background images, 
  print preview, export to HTML and RTF, data-aware versions 
  and more...
{---------------------------------------------------------------}
                     CONTENTS
D6\          - shareware version for Delphi 6
               (trial versions for Delphi 2-5 and C++Builder 1-5
               are available on web site)
HTML\        - general information about components
HELP\        - help file
DEMOS\       - demo projects:
 DEMOS\EDITOR\     - example of RichViewEdit-based editor (with EXE)
 DEMOS\MULTIDEMO\  - multi-demo application (with EXE)
 DEMOS\TUTORIAL\   - tutorial projects, please read
                     Demos\Tutorial\Tutorial.txt 
 DEMOS\ASSORTED\   - other projects, please read
                     Demos\Assorted\ReadMe.txt 
INSTALL.TXT  - installation Instructions
LICENSE.TXT  - license agreement
REGISTER.TXT - ordering information
{---------------------------------------------------------------}
                     CONTACTS
WWW main Site: www.trichview.com
WWW mirror:    www.richedit.com
E-mail:        svt@trichview.com (Sergey Tkachenko)
{---------------------------------------------------------------}
May 18 2001