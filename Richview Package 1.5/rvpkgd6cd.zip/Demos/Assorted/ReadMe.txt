========================= Assorted projects ====================
RichEdit
   How to implement RichEdit-style editing operations
   (make bold, apply font, etc.)
   Requires Delphi 3+ (because of components you need to
   install to compile this demo).
Load RVF
   How to load file, created in editor demo.
(New in 1.4) Save HTML and Table Hypertext
   Loading RVF files (created in editor demo) and saving
   them in HTML using advanced features.
   (uses free Anders Melander's TGifImage,
   http://www.melander.dk/delphi/gifimage/,
   but can be modified to work with other GIF implementations
   supporting assignment from other graphic formats)
   Also demonstrated using hypertext with tables.
Printing
   How to print document.
DB Demo
   Data-aware versions of components.
CustomDraw
   Custom drawing in RichView.
   (Delphi3+, C++Builder3+ required, since
    TBitmap.ScanLines property was used)
(New in 1.4)CustomDraw
   One more example of custom drawing (math-style)
(New in 1.4)Search and Replace
Using search and replace dialog with TRichViewEdit
================ How to use with C++Builder ====================
Create new C++Builder project (application). Remove form from this
project. Add form from tutorial project (most of tutorial projects
have only one form). Compile.
================================================================