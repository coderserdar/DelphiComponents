// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Compress.pas' rev: 5.00

#ifndef CompressHPP
#define CompressHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Compress
{
//-- type declarations -------------------------------------------------------
typedef char textbuffer[4156];

typedef char *textbufptr;

typedef short lsons[4097];

typedef short *lsonptr;

typedef short rsons[8194];

typedef short *rsonptr;

typedef short dads[4098];

typedef short *dadptr;

typedef char samebuf[4098];

typedef char *samebufptr;

typedef Word freqs[628];

typedef Word *freqptr;

typedef short prnts[942];

typedef short *prntptr;

typedef short sons[628];

typedef short *sonptr;

typedef char textbuffer5[16641];

typedef char levelbuffer[8449];

typedef char childcountbuffer[8449];

typedef short node;

typedef short positionbuffer[8449];

typedef short *positionptr;

typedef short parentbuffer[16385];

typedef short prevbuffer[16385];

typedef short nextbuffer[28913];

typedef char buffer[16385];

typedef char *bufferptr;

typedef Word childBuffer[1020];

typedef Word chartablebuffer[4097];

typedef Word charcodebuffer[511];

typedef Word positiontablebuffer[257];

typedef char charlenbuffer[511];

typedef Word positioncodebuffer[129];

class DELPHICLASS ELZHBadDecodeTable;
class PASCALIMPLEMENTATION ELZHBadDecodeTable : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall ELZHBadDecodeTable(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall ELZHBadDecodeTable(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall ELZHBadDecodeTable(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall ELZHBadDecodeTable(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall ELZHBadDecodeTable(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall ELZHBadDecodeTable(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall ELZHBadDecodeTable(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall ELZHBadDecodeTable(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~ELZHBadDecodeTable(void) { }
	#pragma option pop
	
};


class DELPHICLASS EUnableToCompress;
class PASCALIMPLEMENTATION EUnableToCompress : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EUnableToCompress(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EUnableToCompress(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EUnableToCompress(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EUnableToCompress(int Ident, const System::TVarRec * 
		Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EUnableToCompress(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EUnableToCompress(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EUnableToCompress(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EUnableToCompress(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EUnableToCompress(void) { }
	#pragma option pop
	
};


class DELPHICLASS EInsufficientDiskSpace;
class PASCALIMPLEMENTATION EInsufficientDiskSpace : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EInsufficientDiskSpace(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EInsufficientDiskSpace(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EInsufficientDiskSpace(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EInsufficientDiskSpace(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EInsufficientDiskSpace(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EInsufficientDiskSpace(const AnsiString Msg, const 
		System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size
		, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EInsufficientDiskSpace(int Ident, int AHelpContext)
		/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EInsufficientDiskSpace(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EInsufficientDiskSpace(void) { }
	#pragma option pop
	
};


class DELPHICLASS EUnrecognizedCompressionMethod;
class PASCALIMPLEMENTATION EUnrecognizedCompressionMethod : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EUnrecognizedCompressionMethod(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EUnrecognizedCompressionMethod(const AnsiString Msg, const 
		System::TVarRec * Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EUnrecognizedCompressionMethod(int Ident)/* overload */
		 : Sysutils::Exception(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EUnrecognizedCompressionMethod(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EUnrecognizedCompressionMethod(const AnsiString Msg, int 
		AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EUnrecognizedCompressionMethod(const AnsiString Msg
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, 
		Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EUnrecognizedCompressionMethod(int Ident, int AHelpContext
		)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EUnrecognizedCompressionMethod(System::PResStringRec 
		ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : 
		Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EUnrecognizedCompressionMethod(void) { }
	#pragma option pop
	
};


class DELPHICLASS EInvalidHeaderArchiveType;
class PASCALIMPLEMENTATION EInvalidHeaderArchiveType : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EInvalidHeaderArchiveType(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EInvalidHeaderArchiveType(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EInvalidHeaderArchiveType(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EInvalidHeaderArchiveType(int Ident, const System::TVarRec 
		* Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EInvalidHeaderArchiveType(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EInvalidHeaderArchiveType(const AnsiString Msg, const 
		System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size
		, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EInvalidHeaderArchiveType(int Ident, int AHelpContext
		)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EInvalidHeaderArchiveType(System::PResStringRec 
		ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : 
		Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EInvalidHeaderArchiveType(void) { }
	#pragma option pop
	
};


class DELPHICLASS EInvalidHeader;
class PASCALIMPLEMENTATION EInvalidHeader : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EInvalidHeader(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EInvalidHeader(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EInvalidHeader(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EInvalidHeader(int Ident, const System::TVarRec * Args
		, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EInvalidHeader(const AnsiString Msg, int AHelpContext)
		 : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EInvalidHeader(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EInvalidHeader(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EInvalidHeader(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EInvalidHeader(void) { }
	#pragma option pop
	
};


class DELPHICLASS EBadChecksum;
class PASCALIMPLEMENTATION EBadChecksum : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EBadChecksum(const AnsiString Msg) : Sysutils::Exception(Msg
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EBadChecksum(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EBadChecksum(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EBadChecksum(int Ident, const System::TVarRec * Args
		, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EBadChecksum(const AnsiString Msg, int AHelpContext) : 
		Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EBadChecksum(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EBadChecksum(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EBadChecksum(System::PResStringRec ResStringRec, 
		const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EBadChecksum(void) { }
	#pragma option pop
	
};


class DELPHICLASS EInvalidKey;
class PASCALIMPLEMENTATION EInvalidKey : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EInvalidKey(const AnsiString Msg) : Sysutils::Exception(Msg
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EInvalidKey(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EInvalidKey(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EInvalidKey(int Ident, const System::TVarRec * Args, 
		const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EInvalidKey(const AnsiString Msg, int AHelpContext) : 
		Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EInvalidKey(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EInvalidKey(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EInvalidKey(System::PResStringRec ResStringRec, 
		const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EInvalidKey(void) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TCompressArchiveType { caSingle, caMulti };
#pragma option pop

#pragma option push -b-
enum TCompressionMethod { coNone, coRLE, coLZH, coCustom, coLZH5 };
#pragma option pop

#pragma option push -b-
enum TCProcessMode { cmCompress, cmExpand, cmDelete };
#pragma option pop

struct TCompressHeader
{
	char ComId[5];
	char ComMethodId[3];
	int Fullsize;
	TCompressArchiveType ArchiveType;
	int Checksum;
	int Locked;
} ;

struct TCompressedFileHeader
{
	short FileNameLength;
	int Datetime;
	short Attributes;
	int Fullsize;
	int CompressedSize;
	TCompressionMethod CompressedMode;
	int Checksum;
	int Locked;
} ;

class DELPHICLASS TCompressedFileInfo;
class PASCALIMPLEMENTATION TCompressedFileInfo : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	int Datetime;
	short Attributes;
	int Fullsize;
	int CompressedSize;
	TCompressionMethod CompressedMode;
	int Checksum;
	int Position;
	bool Locked;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TCompressedFileInfo(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TCompressedFileInfo(void) { }
	#pragma option pop
	
};


typedef void __fastcall (__closure *TFilenameCheckEvent)(AnsiString &filepath, TCProcessMode mode);

typedef void __fastcall (__closure *TCompressEvent)(Classes::TStream* dest, Classes::TStream* source
	, AnsiString &CompressID, int &Outputsize, int &checksum);

typedef void __fastcall (__closure *TExpandEvent)(Classes::TStream* dest, Classes::TStream* source, 
	int Sourcesize, int Destsize, AnsiString CompressID, int &checksum);

typedef void __fastcall (__closure *TRecognizeEvent)(AnsiString CompressID, bool &recognized);

typedef void __fastcall (__closure *TShowProgressEvent)(int &PercentageDone);

class DELPHICLASS TCompThreadSafety;
class PASCALIMPLEMENTATION TCompThreadSafety : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	bool AtStart;
	bool InputEOF;
	bool inRepeat;
	char *inBuffer;
	char *outBuffer;
	char *inBmax;
	char *inBptr;
	char *outBmax;
	char *outBptr;
	Classes::TStream* source;
	Classes::TStream* dest;
	char lastch;
	int DupCount;
	int InChecksum;
	int Outchecksum;
	int Readsize;
	int lChunk;
	int BytesIn;
	int BytesOut;
	bool EncryptingIn;
	bool EncryptingOut;
	Byte EncryptCodes[4];
	short EncryptCounter;
	int MaxNumberOfBytesToWrite;
	TShowProgressEvent GlobalFOnShowProgress;
	char *text_buf;
	short *lson;
	short *rson;
	short *dad;
	char *same;
	Word *freq;
	short *prnt;
	short *son;
	Word putbuf;
	char putlen;
	Word getbuf;
	char getlen;
	Word match_position;
	Word match_length;
	char *text;
	char *level;
	char *childcount;
	short *position;
	short *parent;
	short *prev;
	char *buf;
	char subBitbuf;
	char Bitcount;
	Word Blocksize;
	Word bitbuf;
	Word *left;
	Word *right;
	char *charLen;
	char position_len[129];
	Word *char_freq;
	Word *char_table;
	Word *char_code;
	Word position_freq[28];
	Word *position_table;
	Word *position_code;
	Word t_freq[38];
	short pos;
	short MatchPosition;
	short avail;
	short *next;
	char depth;
	Word output_pos;
	Word output_mask;
	Word cpos;
	short remainder;
	short MatchLength;
	char __fastcall GetChar(void);
	char __fastcall Encrypt(char ch);
	void __fastcall PutChar(char ch);
	void __fastcall CopyWithCRC(void);
	void __fastcall emit(int count, char ch);
	void __fastcall CompressRLE(void);
	void __fastcall ExpandRLE(void);
	void __fastcall StartHuff(void);
	void __fastcall EndHuff(void);
	void __fastcall reconst(void);
	void __fastcall update(Word c);
	void __fastcall InitTree(void);
	void __fastcall InsertNode(short r);
	void __fastcall link(short n, short p, short q);
	void __fastcall linknode(short p, short q, short r);
	void __fastcall DeleteNode(short p);
	void __fastcall Putcode(short L, Word c);
	void __fastcall EncodeChar(Word c);
	void __fastcall EncodePosition(Word c);
	void __fastcall EncodeEnd(void);
	void __fastcall CompressLZH(void);
	short __fastcall GetBit(void);
	Word __fastcall GetByte(void);
	short __fastcall GetNBits(Word n);
	short __fastcall DecodeChar(void);
	short __fastcall DecodePosition(void);
	void __fastcall ExpandLZH(int textsize);
	void __fastcall StartHuff5(bool Compress);
	void __fastcall EndHuff5(void);
	void __fastcall buildtable(short nchar, const char * bitlen, const int bitlen_Size, short tablebits
		, Word * table, const int table_Size);
	void __fastcall fillbuf(char n);
	Word __fastcall getbits(char n);
	void __fastcall read_position_len(short nn, short nbit, short i_special);
	void __fastcall read_charLen(void);
	Word __fastcall DecodeChar5(void);
	Word __fastcall DecodePosition5(void);
	void __fastcall ExpandLZH5(int destsize);
	short __fastcall buildtree(short nparm, Word * freqparm, const int freqparm_Size, char * lenparm, const 
		int lenparm_Size, Word * codeparm, const int codeparm_Size);
	void __fastcall count_t_freq(void);
	void __fastcall initSlide(void);
	short __fastcall child(short q, char c);
	void __fastcall makechild(short q, char c, short r);
	void __fastcall split(short old);
	void __fastcall insert_node(void);
	void __fastcall delete_node(void);
	void __fastcall putcode5(char n, Word x);
	void __fastcall putbits(char n, Word x);
	void __fastcall write_position_len(short n, short nbit, short i_special);
	void __fastcall write_charLen(void);
	void __fastcall encode_char(short c);
	void __fastcall encode_position(Word p);
	void __fastcall send_block(void);
	void __fastcall OutputCodes(Word c, Word p);
	void __fastcall get_next_match(void);
	void __fastcall CompressLZH5(void);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TCompThreadSafety(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TCompThreadSafety(void) { }
	#pragma option pop
	
};


class DELPHICLASS TCompress;
class PASCALIMPLEMENTATION TCompress : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	TCompThreadSafety* Global;
	AnsiString FRegName;
	int FRegNumber;
	int FCompressedToPercentage;
	unsigned FCompressionTime;
	TCompressEvent FOnCompress;
	TExpandEvent FOnExpand;
	TRecognizeEvent FOnRecognize;
	TFilenameCheckEvent FOnCheckFile;
	TShowProgressEvent FOnShowProgress;
	AnsiString FTargetPath;
	bool FMakeDirectories;
	int FKeyNum;
	bool FExceptionOnFileError;
	bool FCheckSpaceBeforeExpand;
	int FMustCompressByAtLeast;
	AnsiString __fastcall ProcessString(const AnsiString str, TCompressionMethod compressionMethod, TCProcessMode 
		mode);
	int __fastcall CheckDiskSpace(AnsiString filename);
	void __fastcall SetTargetPath(const AnsiString path);
	int __fastcall GetCompressedPercentage(void);
	int __fastcall ProcessStreams(Classes::TStream* outstream, Classes::TStream* instream, int Sourcesize
		, int destSize, TCompressionMethod CompressionMethod, int &checksum, TCProcessMode mode, bool Encrypted
		);
	
protected:
	void __fastcall AppendFilesExcept(const AnsiString destfile, const AnsiString fromfile, Classes::TStringList* 
		notfiles);
	void __fastcall SetHeader(TCompressHeader &hdr, AnsiString cID, TCompressArchiveType aType, int size
		);
	bool __fastcall GetFileHeader(Classes::TStream* Stream, TCompressedFileHeader &Fhdr, AnsiString &Filename
		);
	void __fastcall PutFileHeader(Classes::TStream* Stream, TCompressedFileHeader &Fhdr, const AnsiString 
		Filename);
	void __fastcall CheckHeader(Classes::TStream* compressedFile, TCompressHeader &hdr, AnsiString &CID
		);
	
public:
	__fastcall virtual TCompress(Classes::TComponent* AOwner);
	__fastcall virtual ~TCompress(void);
	float __fastcall DiskFree(Byte Drive);
	AnsiString __fastcall CompressString(const AnsiString unCompressedString, TCompressionMethod compressionMethod
		);
	AnsiString __fastcall ExpandString(const AnsiString CompressedString);
	int __fastcall DoCompress(Classes::TStream* compressedStream, Classes::TStream* uncompressedStream, 
		TCompressionMethod compressionMethod, AnsiString &CompressID, int &checksum);
	void __fastcall DoExpand(Classes::TStream* expandedStream, Classes::TStream* unexpandedStream, int 
		compressedsize, int fullsize, int checksum, TCompressionMethod compressionMethod, const AnsiString 
		CompressID, int FLocked);
	TCompressionMethod __fastcall Recognize(const AnsiString cID);
	void __fastcall Compress(Classes::TStream* compressedStream, Classes::TStream* uncompressedStream, 
		TCompressionMethod compressionMethod);
	void __fastcall Expand(Classes::TStream* expandedStream, Classes::TStream* unexpandedStream);
	void __fastcall CompressStreamToArchiveStream(Classes::TStream* compressedStream, Classes::TStream* 
		uncompressedStream, const AnsiString Filename, const TCompressedFileHeader &FHdr, AnsiString &cID, 
		TCompressionMethod CompressionMode);
	void __fastcall CompressStreamToArchive(AnsiString arcFile, Classes::TStream* uncompressedStream, const 
		AnsiString fileName, TCompressionMethod CompressionMode);
	void __fastcall ExpandStreamFromArchive(AnsiString arcFile, Classes::TStream* uncompressedStream, AnsiString 
		fileName);
	int __fastcall CompressFilesToStream(Classes::TStream* dest, Classes::TStringList* &whichfiles, TCompressionMethod 
		CompressionMode);
	void __fastcall CompressFiles(const AnsiString arcFile, Classes::TStringList* whichfiles, TCompressionMethod 
		CompressionMode);
	void __fastcall CompressFile(const AnsiString arcfile, AnsiString &fromFile, TCompressionMethod CompressionMode
		);
	void __fastcall DeleteFiles(const AnsiString arcFile, Classes::TStringList* whichfiles);
	void __fastcall ExpandFile(AnsiString &toFile, const AnsiString arcfile);
	void __fastcall ExpandFiles(const AnsiString arcfile, Classes::TStringList* whichfiles);
	void __fastcall ExpandFilesFromStream(Classes::TStream* compressedstream, Classes::TStringList* whichfiles
		);
	void __fastcall ScanCompressedStream(Classes::TStream* compressedstream, Classes::TStringList* &Finfo
		);
	void __fastcall ScanCompressedFile(const AnsiString arcfile, Classes::TStringList* &Finfo);
	__property int CompressedPercentage = {read=GetCompressedPercentage, nodefault};
	__property unsigned CompressionTime = {read=FCompressionTime, nodefault};
	Classes::TStream* __fastcall LoadCompressedResource(AnsiString ResourceName, AnsiString DLLName);
	Classes::TStream* __fastcall LoadExpandedResource(AnsiString ResourceName, AnsiString DLLName);
	void __fastcall FreeFileList(Classes::TStringList* Finfo);
	void __fastcall GetAllFilesInDir(Classes::TStringList* list, AnsiString dirname, const AnsiString match
		, bool Anything);
	void __fastcall GetMatchingFiles(Classes::TStringList* list, const AnsiString matchname);
	
__published:
	__property AnsiString RegName = {read=FRegName, write=FRegName};
	__property int RegNumber = {read=FRegNumber, write=FRegNumber, nodefault};
	__property TCompressEvent OnCompress = {read=FOnCompress, write=FOnCompress};
	__property TExpandEvent OnExpand = {read=FOnExpand, write=FOnExpand};
	__property TFilenameCheckEvent OnCheckFile = {read=FOnCheckFile, write=FOnCheckFile};
	__property TRecognizeEvent OnRecognize = {read=FOnRecognize, write=FOnRecognize};
	__property TShowProgressEvent OnShowProgress = {read=FOnShowProgress, write=FOnShowProgress};
	__property AnsiString TargetPath = {read=FTargetPath, write=SetTargetPath};
	__property bool MakeDirectories = {read=FMakeDirectories, write=FMakeDirectories, nodefault};
	__property bool ExceptionOnFileError = {read=FExceptionOnFileError, write=FExceptionOnFileError, nodefault
		};
	__property int Key = {read=FKeyNum, write=FKeyNum, nodefault};
	__property bool CheckSpaceBeforeExpand = {read=FCheckSpaceBeforeExpand, write=FCheckSpaceBeforeExpand
		, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
static const Word N = 0x1000;
static const Word TNIL = 0x1000;
static const Shortint F = 0x3c;
static const Shortint THRESHOLD = 0x2;
static const Word N_CHAR = 0x13a;
static const Word T = 0x273;
static const Word R = 0x272;
static const Word MAX_FREQ = 0x8000;
static const Word MaxMatch = 0x100;
static const Shortint DictionaryBits = 0xd;
static const Word DictionarySize = 0x2000;
static const Shortint Hash1 = 0x4;
static const Word Hash2 = 0x4000;
static const Byte CharMax = 0xff;
static const Word WordMax = 0xffff;
static const Shortint WordBits = 0x10;
static const Word SmallintMax = 0x7fff;
static const short SmallintMin = 0xffff8000;
static const Word max_hash_val = 0x70ef;
static const Word BufferSize = 0x4000;
static const Shortint Threshold5 = 0x3;
static const Word NC = 0x1fe;
static const Shortint CBIT = 0x9;
static const Shortint PBIT = 0x4;
static const Shortint TBIT = 0x5;
static const Shortint NP = 0xe;
static const Shortint NT = 0x13;
static const Byte NPT = 0x80;
static const Shortint NIL5 = 0x0;
static const char CompressNoMoreFlag = '\x2a';
#define CompressSkipFlag ""
extern PACKAGE void __fastcall Register(void);

}	/* namespace Compress */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Compress;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Compress
