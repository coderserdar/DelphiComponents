// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Compmain.pas' rev: 5.00

#ifndef CompmainHPP
#define CompmainHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Mask.hpp>	// Pascal unit
#include <FileCtrl.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <Compctrl.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <DBTables.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Compress.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Compmain
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TForm1;
class PASCALIMPLEMENTATION TForm1 : public Forms::TForm 
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* Panel2;
	Extctrls::TShape* Shape1;
	Dbctrls::TDBText* DBText1;
	Extctrls::TImage* Image1;
	Stdctrls::TMemo* Memo1;
	Stdctrls::TMemo* Memo2;
	Dbctrls::TDBNavigator* DBNavigator1;
	Extctrls::TRadioGroup* CMethod;
	Stdctrls::TGroupBox* GroupBox1;
	Filectrl::TFileListBox* FL;
	Filectrl::TDirectoryListBox* DL;
	Filectrl::TDriveComboBox* DCB;
	Stdctrls::TMemo* Memo3;
	Stdctrls::TGroupBox* ArchiveGroup;
	Stdctrls::TLabel* ArchiveLabel;
	Stdctrls::TLabel* Label2;
	Stdctrls::TEdit* archivefile;
	Stdctrls::TListBox* ListBox1;
	Stdctrls::TMemo* Memo4;
	Dbctrls::TDBEdit* Fishname;
	Stdctrls::TMemo* Memo5;
	Stdctrls::TMemo* Memo6;
	Stdctrls::TButton* Button1;
	Extctrls::TPanel* Panel1;
	Extctrls::TBevel* Bevel1;
	Stdctrls::TLabel* Time;
	Stdctrls::TLabel* Percentage;
	Stdctrls::TLabel* TimeLabel;
	Stdctrls::TLabel* Label7;
	Extctrls::TImage* Trashcan;
	Stdctrls::TButton* Button2;
	Compctrl::TCDBImage* CDBImage1;
	Compctrl::TCDBMemo* CDBMemo1;
	Stdctrls::TButton* Button3;
	Dbtables::TTable* Table1;
	Db::TFloatField* Table1SpeciesNo;
	Db::TStringField* Table1Category;
	Db::TStringField* Table1Common_Name;
	Db::TStringField* Table1SpeciesName;
	Db::TFloatField* Table1Lengthcm;
	Db::TFloatField* Table1Length_In;
	Compctrl::TCGraphicField* CDBImage1Graphic;
	Compctrl::TCMemoField* CDBMemo1Notes;
	Db::TDataSource* DataSource1;
	Compress::TCompress* Compress1;
	void __fastcall CompressOneFile(AnsiString &fname);
	void __fastcall ResetFileInfo(void);
	AnsiString __fastcall GetDir();
	AnsiString __fastcall GetDummyFilename(AnsiString generatefrom, AnsiString ext);
	void __fastcall handleDropField(System::TObject* Source, bool archivetoo);
	void __fastcall SaveDirectToArchive(Db::TField* Source, AnsiString filename);
	void __fastcall CompressFiles(void);
	Compress::TCompressionMethod __fastcall getCompressionMethod(void);
	void __fastcall showInfo(Compress::TCompress* comp);
	void __fastcall FormCreate(System::TObject* Sender);
	void __fastcall showfiles(void);
	void __fastcall ExpandDelete(Compress::TCProcessMode Operation, bool All);
	void __fastcall archivefileChange(System::TObject* Sender);
	void __fastcall CMethodClick(System::TObject* Sender);
	void __fastcall DLDragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, Controls::TDragState 
		State, bool &Accept);
	void __fastcall CDBImage1DragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, Controls::TDragState 
		State, bool &Accept);
	void __fastcall CDBImage1DragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y);
	void __fastcall CDBMemo1DragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, Controls::TDragState 
		State, bool &Accept);
	void __fastcall CDBMemo1DragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y);
	void __fastcall CDBImage1MouseDown(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState 
		Shift, int X, int Y);
	void __fastcall CDBMemo1MouseDown(System::TObject* Sender, Controls::TMouseButton Button, Classes::TShiftState 
		Shift, int X, int Y);
	void __fastcall archivefileDragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, 
		Controls::TDragState State, bool &Accept);
	void __fastcall archivefileDragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y)
		;
	void __fastcall DLDragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y);
	void __fastcall TrashcanDragDrop(System::TObject* Sender, System::TObject* Source, int X, int Y);
	void __fastcall FormDestroy(System::TObject* Sender);
	void __fastcall ListBox1Click(System::TObject* Sender);
	void __fastcall Table1AfterPost(Db::TDataSet* DataSet);
	void __fastcall Button1Click(System::TObject* Sender);
	void __fastcall FLClick(System::TObject* Sender);
	void __fastcall Compress1CheckFile(AnsiString &filepath, Compress::TCProcessMode mode);
	void __fastcall Panel1Click(System::TObject* Sender);
	void __fastcall FormClick(System::TObject* Sender);
	void __fastcall GroupBox1Click(System::TObject* Sender);
	void __fastcall TrashcanDragOver(System::TObject* Sender, System::TObject* Source, int X, int Y, Controls::TDragState 
		State, bool &Accept);
	void __fastcall Button2Click(System::TObject* Sender);
	void __fastcall Compress1ShowProgress(int &PercentageDone);
	void __fastcall Button3Click(System::TObject* Sender);
	void __fastcall disabledragMode(void);
	void __fastcall enabledragMode(void);
	void __fastcall Button4Click(System::TObject* Sender);
public:
	#pragma option push -w-inl
	/* TCustomForm.Create */ inline __fastcall virtual TForm1(Classes::TComponent* AOwner) : Forms::TForm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.CreateNew */ inline __fastcall virtual TForm1(Classes::TComponent* AOwner, int Dummy
		) : Forms::TForm(AOwner, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TForm1(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TForm1(HWND ParentWindow) : Forms::TForm(ParentWindow
		) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TForm1* Form1;

}	/* namespace Compmain */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Compmain;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Compmain
