// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Compctrl.pas' rev: 5.00

#ifndef CompctrlHPP
#define CompctrlHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <DBTables.hpp>	// Pascal unit
#include <DBCtrls.hpp>	// Pascal unit
#include <Compress.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <ComCtrls.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <Mask.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Compctrl
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCBlobField;
class PASCALIMPLEMENTATION TCBlobField : public Db::TBlobField 
{
	typedef Db::TBlobField inherited;
	
private:
	bool Ftransliterate;
	Compress::TCompress* FCompressSource;
	Compress::TCompressionMethod FCompressionMethod;
	HIDESBASE Db::TBlobType __fastcall GetBlobType(void);
	HIDESBASE void __fastcall LoadFromBlob(Db::TBlobField* Blob);
	HIDESBASE void __fastcall LoadFromStrings(Classes::TStrings* Strings);
	HIDESBASE void __fastcall LoadFromBitmap(Graphics::TBitmap* Bitmap);
	HIDESBASE void __fastcall SaveToBitmap(Graphics::TBitmap* Bitmap);
	HIDESBASE void __fastcall SaveToStrings(Classes::TStrings* Strings);
	HIDESBASE void __fastcall SetBlobType(Db::TBlobType Value);
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual AnsiString __fastcall GetAsString();
	virtual Variant __fastcall GetAsVariant();
	virtual int __fastcall GetBlobSize(void);
	virtual bool __fastcall GetIsNull(void);
	virtual void __fastcall GetText(AnsiString &Text, bool DisplayText);
	virtual void __fastcall SetAsString(const AnsiString Value);
	virtual void __fastcall SetText(const AnsiString Value);
	virtual void __fastcall SetVarValue(const Variant &Value);
	
public:
	__fastcall virtual TCBlobField(Classes::TComponent* AOwner);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	virtual void __fastcall Clear(void);
	#pragma option push -w-inl
	/* virtual class method */ virtual bool __fastcall IsBlob() { return IsBlob(__classid(TCBlobField)); }
		
	#pragma option pop
	/*         class method */ static bool __fastcall IsBlob(TMetaClass* vmt);
	HIDESBASE void __fastcall LoadFromFile(const AnsiString FileName);
	HIDESBASE void __fastcall LoadFromStream(Classes::TStream* Stream);
	HIDESBASE void __fastcall SaveToFile(const AnsiString FileName);
	HIDESBASE void __fastcall SaveToStream(Classes::TStream* Stream);
	virtual void __fastcall SetFieldType(Db::TFieldType Value);
	__property int BlobSize = {read=GetBlobSize, nodefault};
	__property AnsiString Value = {read=GetAsString, write=SetAsString};
	__property bool Transliterate = {read=Ftransliterate, write=Ftransliterate, nodefault};
	
__published:
	__property Db::TBlobType BlobType = {read=GetBlobType, write=SetBlobType, nodefault};
	__property Size ;
	__property Compress::TCompress* CompressSource = {read=FCompressSource, write=FCompressSource};
	__property Compress::TCompressionMethod CompressionMethod = {read=FCompressionMethod, write=FCompressionMethod
		, nodefault};
public:
	#pragma option push -w-inl
	/* TField.Destroy */ inline __fastcall virtual ~TCBlobField(void) { }
	#pragma option pop
	
};


class DELPHICLASS TCMemoField;
class PASCALIMPLEMENTATION TCMemoField : public TCBlobField 
{
	typedef TCBlobField inherited;
	
public:
	__fastcall virtual TCMemoField(Classes::TComponent* AOwner);
	__property Transliterate ;
public:
	#pragma option push -w-inl
	/* TField.Destroy */ inline __fastcall virtual ~TCMemoField(void) { }
	#pragma option pop
	
};


class DELPHICLASS TCGraphicField;
class PASCALIMPLEMENTATION TCGraphicField : public TCBlobField 
{
	typedef TCBlobField inherited;
	
public:
	__fastcall virtual TCGraphicField(Classes::TComponent* AOwner);
public:
	#pragma option push -w-inl
	/* TField.Destroy */ inline __fastcall virtual ~TCGraphicField(void) { }
	#pragma option pop
	
};


class DELPHICLASS TCDBMemo;
class PASCALIMPLEMENTATION TCDBMemo : public Stdctrls::TCustomMemo 
{
	typedef Stdctrls::TCustomMemo inherited;
	
private:
	TCMemoField* FCField;
	Compress::TCompress* FCompressSource;
	Compress::TCompressionMethod FCompressionMethod;
	Dbctrls::TFieldDataLink* FDataLink;
	bool FAutoDisplay;
	bool FFocused;
	bool FMemoLoaded;
	Dbctrls::TPaintControl* FPaintControl;
	void __fastcall DataChange(System::TObject* Sender);
	void __fastcall EditingChange(System::TObject* Sender);
	AnsiString __fastcall GetDataField();
	Db::TDataSource* __fastcall GetDataSource(void);
	Db::TField* __fastcall GetField(void);
	bool __fastcall GetReadOnly(void);
	void __fastcall CheckSetCompressedField(void);
	void __fastcall SetCompressionMethod(Compress::TCompressionMethod value);
	void __fastcall SetCompressSource(Compress::TCompress* value);
	void __fastcall SetDataField(const AnsiString Value);
	void __fastcall SetDataSource(Db::TDataSource* Value);
	HIDESBASE void __fastcall SetReadOnly(bool Value);
	void __fastcall SetAutoDisplay(bool Value);
	void __fastcall SetFocused(bool Value);
	void __fastcall UpdateData(System::TObject* Sender);
	MESSAGE void __fastcall WMCut(Messages::TMessage &Message);
	MESSAGE void __fastcall WMPaste(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMEnter(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall CMExit(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDblClk(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMPaint(Messages::TWMPaint &Message);
	MESSAGE void __fastcall CMGetDataLink(Messages::TMessage &Message);
	
protected:
	DYNAMIC void __fastcall Change(void);
	__property TCMemoField* CompressedField = {read=FCField, write=FCField};
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall KeyPress(char &Key);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	virtual void __fastcall WndProc(Messages::TMessage &Message);
	
public:
	__fastcall virtual TCDBMemo(Classes::TComponent* AOwner);
	__fastcall virtual ~TCDBMemo(void);
	void __fastcall LoadMemo(void);
	__property Db::TField* Field = {read=GetField};
	__property TCMemoField* CField = {read=FCField};
	DYNAMIC bool __fastcall ExecuteAction(Classes::TBasicAction* Action);
	DYNAMIC bool __fastcall UpdateAction(Classes::TBasicAction* Action);
	DYNAMIC bool __fastcall UseRightToLeftAlignment(void);
	
__published:
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
	__property OnContextPopup ;
	__property Align ;
	__property Alignment ;
	__property bool AutoDisplay = {read=FAutoDisplay, write=SetAutoDisplay, default=1};
	__property BorderStyle ;
	__property Color ;
	__property Compress::TCompressionMethod CompressionMethod = {read=FCompressionMethod, write=SetCompressionMethod
		, nodefault};
	__property Compress::TCompress* CompressSource = {read=FCompressSource, write=SetCompressSource};
	__property Ctl3D ;
	__property AnsiString DataField = {read=GetDataField, write=SetDataField};
	__property Db::TDataSource* DataSource = {read=GetDataSource, write=SetDataSource};
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property ImeMode ;
	__property ImeName ;
	__property MaxLength ;
	__property ParentColor ;
	__property ParentCtl3D ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property bool ReadOnly = {read=GetReadOnly, write=SetReadOnly, default=0};
	__property ScrollBars ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property Visible ;
	__property WantTabs ;
	__property WordWrap ;
	__property OnChange ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCDBMemo(HWND ParentWindow) : Stdctrls::TCustomMemo(
		ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TCDBImage;
class PASCALIMPLEMENTATION TCDBImage : public Controls::TCustomControl 
{
	typedef Controls::TCustomControl inherited;
	
private:
	TCGraphicField* FCField;
	Compress::TCompress* FCompressSource;
	Compress::TCompressionMethod FCompressionMethod;
	Dbctrls::TFieldDataLink* FDataLink;
	Graphics::TPicture* FPicture;
	Forms::TFormBorderStyle FBorderStyle;
	bool FAutoDisplay;
	bool FStretch;
	bool FCenter;
	bool FPictureLoaded;
	bool FQuickDraw;
	void __fastcall CheckSetCompressedField(void);
	void __fastcall DataChange(System::TObject* Sender);
	AnsiString __fastcall GetDataField();
	Db::TDataSource* __fastcall GetDataSource(void);
	Db::TField* __fastcall GetField(void);
	bool __fastcall GetReadOnly(void);
	void __fastcall PictureChanged(System::TObject* Sender);
	void __fastcall SetAutoDisplay(bool Value);
	void __fastcall SetBorderStyle(Forms::TBorderStyle Value);
	void __fastcall SetCenter(bool Value);
	void __fastcall SetCompressionMethod(Compress::TCompressionMethod value);
	void __fastcall SetCompressSource(Compress::TCompress* value);
	void __fastcall SetDataField(const AnsiString Value);
	void __fastcall SetDataSource(Db::TDataSource* Value);
	void __fastcall SetPicture(Graphics::TPicture* Value);
	void __fastcall SetReadOnly(bool Value);
	void __fastcall SetStretch(bool Value);
	void __fastcall UpdateData(System::TObject* Sender);
	HIDESBASE MESSAGE void __fastcall CMEnter(Messages::TWMNoParams &Message);
	MESSAGE void __fastcall CMGetDataLink(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMExit(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDown(Messages::TWMMouse &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDblClk(Messages::TWMMouse &Message);
	MESSAGE void __fastcall WMCut(Messages::TMessage &Message);
	MESSAGE void __fastcall WMCopy(Messages::TMessage &Message);
	MESSAGE void __fastcall WMPaste(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall WMSize(Messages::TMessage &Message);
	MESSAGE void __fastcall CMTextChanged(Messages::TMessage &Message);
	
protected:
	virtual void __fastcall CreateParams(Controls::TCreateParams &Params);
	__property TCGraphicField* CompressedField = {read=FCField, write=FCField};
	DYNAMIC HPALETTE __fastcall GetPalette(void);
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall KeyPress(char &Key);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	virtual void __fastcall Paint(void);
	
public:
	__fastcall virtual TCDBImage(Classes::TComponent* AOwner);
	__fastcall virtual ~TCDBImage(void);
	void __fastcall CopyToClipboard(void);
	void __fastcall CutToClipboard(void);
	void __fastcall LoadPicture(void);
	void __fastcall PasteFromClipboard(void);
	__property Db::TField* Field = {read=GetField};
	__property TCGraphicField* CField = {read=FCField};
	__property Graphics::TPicture* Picture = {read=FPicture, write=SetPicture};
	DYNAMIC bool __fastcall ExecuteAction(Classes::TBasicAction* Action);
	DYNAMIC bool __fastcall UpdateAction(Classes::TBasicAction* Action);
	
__published:
	__property Anchors ;
	__property Constraints ;
	__property DragKind ;
	__property OnEndDock ;
	__property OnStartDock ;
	__property Align ;
	__property bool AutoDisplay = {read=FAutoDisplay, write=SetAutoDisplay, default=1};
	__property Forms::TBorderStyle BorderStyle = {read=FBorderStyle, write=SetBorderStyle, default=1};
	__property bool Center = {read=FCenter, write=SetCenter, default=1};
	__property Color ;
	__property Compress::TCompressionMethod CompressionMethod = {read=FCompressionMethod, write=SetCompressionMethod
		, nodefault};
	__property Compress::TCompress* CompressSource = {read=FCompressSource, write=SetCompressSource};
	__property Ctl3D ;
	__property AnsiString DataField = {read=GetDataField, write=SetDataField};
	__property Db::TDataSource* DataSource = {read=GetDataSource, write=SetDataSource};
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property ParentColor ;
	__property ParentCtl3D ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PopupMenu ;
	__property bool ReadOnly = {read=GetReadOnly, write=SetReadOnly, default=0};
	__property bool QuickDraw = {read=FQuickDraw, write=FQuickDraw, default=1};
	__property ShowHint ;
	__property bool Stretch = {read=FStretch, write=SetStretch, default=0};
	__property TabOrder ;
	__property TabStop ;
	__property Visible ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnStartDrag ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCDBImage(HWND ParentWindow) : Controls::TCustomControl(
		ParentWindow) { }
	#pragma option pop
	
};


class DELPHICLASS TCBlobStream;
class PASCALIMPLEMENTATION TCBlobStream : public Classes::TStream 
{
	typedef Classes::TStream inherited;
	
private:
	bool FsaveTransliterateMode;
	bool FOpened;
	TCBlobField* FField;
	bool FModified;
	Dbtables::TBlobStream* FBlobStream;
	Classes::TMemoryStream* FMemoryStream;
	
public:
	__property Dbtables::TBlobStream* BlobStream = {read=FBlobStream};
	__fastcall TCBlobStream(TCBlobField* Field, Db::TBlobStreamMode Mode);
	__fastcall virtual ~TCBlobStream(void);
	virtual int __fastcall Read(void *Buffer, int Count);
	virtual int __fastcall Write(const void *Buffer, int Count);
	virtual int __fastcall Seek(int Offset, Word Origin);
	void __fastcall Truncate(void);
};


class DELPHICLASS TCDBRichEdit;
class PASCALIMPLEMENTATION TCDBRichEdit : public Comctrls::TCustomRichEdit 
{
	typedef Comctrls::TCustomRichEdit inherited;
	
private:
	TCMemoField* FCField;
	Compress::TCompress* FCompressSource;
	Compress::TCompressionMethod FCompressionMethod;
	Dbctrls::TFieldDataLink* FDataLink;
	bool FAutoDisplay;
	bool FFocused;
	bool FMemoLoaded;
	AnsiString FDataSave;
	void __fastcall BeginEditing(void);
	void __fastcall DataChange(System::TObject* Sender);
	void __fastcall EditingChange(System::TObject* Sender);
	AnsiString __fastcall GetDataField();
	Db::TDataSource* __fastcall GetDataSource(void);
	Db::TField* __fastcall GetField(void);
	bool __fastcall GetReadOnly(void);
	void __fastcall CheckSetCompressedField(void);
	void __fastcall SetCompressionMethod(Compress::TCompressionMethod value);
	void __fastcall SetCompressSource(Compress::TCompress* value);
	void __fastcall SetDataField(const AnsiString Value);
	void __fastcall SetDataSource(Db::TDataSource* Value);
	HIDESBASE void __fastcall SetReadOnly(bool Value);
	void __fastcall SetAutoDisplay(bool Value);
	void __fastcall SetFocused(bool Value);
	void __fastcall UpdateData(System::TObject* Sender);
	MESSAGE void __fastcall WMCut(Messages::TMessage &Message);
	MESSAGE void __fastcall WMPaste(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMEnter(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall CMExit(Messages::TWMNoParams &Message);
	HIDESBASE MESSAGE void __fastcall WMLButtonDblClk(Messages::TWMMouse &Message);
	MESSAGE void __fastcall CMGetDataLink(Messages::TMessage &Message);
	
protected:
	DYNAMIC void __fastcall Change(void);
	__property TCMemoField* CompressedField = {read=FCField, write=FCField};
	DYNAMIC void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall KeyPress(char &Key);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	
public:
	__fastcall virtual TCDBRichEdit(Classes::TComponent* AOwner);
	__fastcall virtual ~TCDBRichEdit(void);
	void __fastcall LoadMemo(void);
	__property Db::TField* Field = {read=GetField};
	__property TCMemoField* CField = {read=FCField};
	DYNAMIC bool __fastcall ExecuteAction(Classes::TBasicAction* Action);
	DYNAMIC bool __fastcall UpdateAction(Classes::TBasicAction* Action);
	DYNAMIC bool __fastcall UseRightToLeftAlignment(void);
	
__published:
	__property Anchors ;
	__property BiDiMode ;
	__property Constraints ;
	__property DragKind ;
	__property ParentBiDiMode ;
	__property OnEndDock ;
	__property OnStartDock ;
	__property Align ;
	__property Alignment ;
	__property bool AutoDisplay = {read=FAutoDisplay, write=SetAutoDisplay, default=1};
	__property BorderStyle ;
	__property Color ;
	__property Compress::TCompressionMethod CompressionMethod = {read=FCompressionMethod, write=SetCompressionMethod
		, nodefault};
	__property Compress::TCompress* CompressSource = {read=FCompressSource, write=SetCompressSource};
	__property Ctl3D ;
	__property AnsiString DataField = {read=GetDataField, write=SetDataField};
	__property Db::TDataSource* DataSource = {read=GetDataSource, write=SetDataSource};
	__property DragCursor ;
	__property DragMode ;
	__property Enabled ;
	__property Font ;
	__property HideSelection ;
	__property HideScrollBars ;
	__property ImeMode ;
	__property ImeName ;
	__property MaxLength ;
	__property ParentColor ;
	__property ParentCtl3D ;
	__property ParentFont ;
	__property ParentShowHint ;
	__property PlainText ;
	__property PopupMenu ;
	__property bool ReadOnly = {read=GetReadOnly, write=SetReadOnly, default=0};
	__property ScrollBars ;
	__property ShowHint ;
	__property TabOrder ;
	__property TabStop ;
	__property Visible ;
	__property WantReturns ;
	__property WantTabs ;
	__property WordWrap ;
	__property OnChange ;
	__property OnClick ;
	__property OnDblClick ;
	__property OnDragDrop ;
	__property OnDragOver ;
	__property OnEndDrag ;
	__property OnEnter ;
	__property OnExit ;
	__property OnKeyDown ;
	__property OnKeyPress ;
	__property OnKeyUp ;
	__property OnMouseDown ;
	__property OnMouseMove ;
	__property OnMouseUp ;
	__property OnResizeRequest ;
	__property OnSelectionChange ;
	__property OnProtectChange ;
	__property OnSaveClipboard ;
	__property OnStartDrag ;
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCDBRichEdit(HWND ParentWindow) : Comctrls::TCustomRichEdit(
		ParentWindow) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Compctrl */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Compctrl;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Compctrl
