DbAltGrid Suite 1.5 Evaluation Edition

  1. General information.
  2. How to istall.
  3. How to uninstall.
  4. Demo projects.
  5. Support.
  6. Features.
  7. New in version 1.5.
  8. How to register.
  9. License agreement.
 10. Disclaimer of warranty.

-----------------------------------------------------------------

1.   G E N E R A L   I N F O R M A T I O N

This evaluation version of DbAltGrid Suite is fully featured. The only difference from the full version is absence of title cell frames in the grid. Projects created with the evaluation version can be completed with the registered version at any time.

DbAltGrid Suite supports Borland Delphi 4, 5, 6 and Borland C++ Builder 4, 5, 6.

Quasidata Ltd.
121, 13 Novgorodskaya, Moscow, 127576 Russia
Tel +7 902 6310492
Fax +7 095 9099385
quasidata@quasidata.com
http://www.quasidata.com/

-----------------------------------------------------------------

2.   H O W   T O   I N S T A L L

- If you have an earler version of DbAltGrid Suite, please be sure to uninstall it before continuing with the installation.
- Run setup.exe to add components and integrated help to the Delphi/C++Builder IDE as well as to install demo programs.
- The changes take effect after the IDE restarts.

-----------------------------------------------------------------

3.   H O W   T O   U N I N S T A L L

- Click the Start button, point to Settings, and then click Control Panel.
- In the Control Panel, double-click Add/Remove Programs.
- In the Add/Remove Programs Properties dialog box, click to select DbAltGrid Suite, and then click Add/Remove. 
- Follow the instructions on your screen to remove all of DbAltGrid Suite. 

-----------------------------------------------------------------

4.   D E M O   P R O J E C T S

The demo programs assume that either DBDEMOS or BCDEMOS database alias exists and that there are CUSTOLY.DB, EVENTS.DB, RESERVAT.DB, VENUES.DB tables within this alias. If that is not the case, this alias and/or tables will have to be reinstalled. Alternatively, you can download the demo tables (about 100 KB) at http://www.quasidata.com/download.html and place them into the project directory.

To compile some of the demo projects, you need a few extra components, Transfer@once by Quasidata, installed in the IDE. You can download them at http://www.quasidata.com/download.html

-----------------------------------------------------------------

5.   S U P P O R T

Send questions to support@quasidata.com or visit the newsgroup at http://www.quasidata.com/forums/

-----------------------------------------------------------------

6.   F E A T U R E S

- MULTIPLE CELL LINES PER RECORD AND MULTIPLE TEXT LINES PER CELL. DbAltGrid allows the user to customize free-form layout. The user can adjust the height of each line in rows separately. Row height and width of each column can be fine-tuned with a double-click.

- HIERARCHICAL COLUMNS. Now you can sort your columns into logical categories, consolidate them and assign to shared parent columns. Parent columns are expandable and collapsible, so this way you can imitate a tree-like column structure. You can MERGE several columns and display them in a RTF summary column. 

- Two-way data transfer through the CLIPBOARD and DRAG-AND-DROP using most popular formats, including ones native to MS Office. Ctrl-Click and Shift-Click selection.

- INPLACE EDITORS for common field types, including numeric, Boolean, date, time, memo, RTF memo, lookup, graphic, and MS Access graphic.

- Displaying of JPEGs, GIFs, bitmaps, metafiles, and icons. ICONS in data cells and headers.

- HYPERLINKS in cells.

- FOOTER panel to display summary for every column.

- AUTO-WIDTH mode. Columns are resized proportionally to fill entire client width.

- Customizable HINT WINDOW for every cell, including title and footer cells.  

- TITLE ARROWS indicate the column the dataset is sorted against as well as sorting possibility for any column.

- FLICKER-FREE painting. Off-screen painting even by custom drawing in OnDrawColumnCell event handler. 

- ALTERNATE ROW COLORING. Background of odd and even rows can be painted with alternate colors like in ledger books.

- MOUSE WHEEL support. The user can scroll records line-by-line or, when holding down the Ctrl key, page-by-page.

- Save and load the grid properties to and from a text file, a stream, a resource file/compiled resource, or the system registry at design-time as well as at runtime. This way you can transfer settings from a DBGrid to a DbAltGrid and vice versa. 

- Smart key mapping. Optional Enter to Tab key automatic conversion. If you want, pressing the Down arrow key when the current record is the last record in the dataset does not result in appending a new empty record. It is made possible with a hot key use. In the MultiSelect mode a user can control whether to select a row or a particular cell.

- SHORT LEARNING CURVE. DbAltGrid is fully compatible with DBGrid that comes with the VCL. The TDbAltGrid class is a TCustomDBGrid descendant, as TDBGrid is. By migration to DbAltGrid, you will not get any code conflicts. There is an auxiliary component to assist with such a migration.

----------------------------------------------------------------

7.   N E W  I N  V E R S I O N  1.5

- C++Builder 6 compliance.

- New Zoom property in TdagGraphic and TdagPicture to control image zooming. 

- A new design-time feature of TdagBackup that makes TDBGrid to TDbAltGrid migration very easy.

- Five new demos.

----------------------------------------------------------------

8.   H O W   T O   R E G I S T E R

You can download the unlimited version and complete source code of DbAltGrid Suite after registration. You will receive the download link instantly after you place the order. After registration you will receive free lifetime upgrades and support.

Visit the page at http://www.quasidata.com/order.html to find out how to register.

-----------------------------------------------------------------

9.   L I C E N S E   A G R E E M E N T

Grant of License for evaluators of this software product. You as an evaluator are granted the right to evaluate the evaluation version of this software product and to distribute the unmodified files to others, at no cost, for evaluation purposes only.

Grant of License for purchased software product. You as a purchaser are granted the right to create and distribute executable files using this software product without additional license or fees. You may not distribute any version of this software product whether it be the original software product or a modified version. You may install a copy of this software product on a computer and freely move the software product from one computer to another, provided that you are the only individual using the software product. If you are an entity, you are granted the right to designate one individual within your organization to have the right to use this software product in the manner provided above.

-----------------------------------------------------------------

10.   D I S C L A I M E R   O F   W A R R A N T Y

This software is provided on an "as is" basis without warranty of any kind, expressed or implied, including but not limited to the implied warranties of merchantability and fitness or a particular purpose. The person using the software bears all risk as to the quality and performance of the software. The author will not be liable for any special, incidental, consequential, indirect or similar damages due to loss of data or any other reason, even if the author or an agent of the author has been advised of the possibility of such damages. In no event shall the author's liability for any damages ever exceed the price paid for the license to use the software, regardless of the form of the claim.

-----------------------------------------------------------------

Copyright � 1999, 2002 Quasidata.